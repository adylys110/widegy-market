-- ============================================================
-- WARUNG KUPHI — Database Schema (MySQL / MariaDB)
-- Compatible: XAMPP / Docker (MySQL 5.7+, MariaDB 10+)
-- ============================================================

CREATE DATABASE IF NOT EXISTS warung_kuphi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE warung_kuphi;

-- ============================================================
-- USERS (Admin, Kasir, Tenant)
-- ============================================================
CREATE TABLE users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(50) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,  -- bcrypt hash
  full_name   VARCHAR(100) NOT NULL,
  role        ENUM('admin','kasir','tenant') NOT NULL DEFAULT 'kasir',
  tenant_id   INT NULL,
  is_active   TINYINT(1) DEFAULT 1,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TENANTS
-- ============================================================
CREATE TABLE tenants (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  description TEXT,
  color       VARCHAR(10) DEFAULT '#059669',
  is_active   TINYINT(1) DEFAULT 1,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

ALTER TABLE users
  ADD CONSTRAINT fk_users_tenant
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE SET NULL;

-- ============================================================
-- CATEGORIES
-- ============================================================
CREATE TABLE categories (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id   INT NOT NULL,
  name        VARCHAR(100) NOT NULL,
  icon        VARCHAR(10) DEFAULT '🍽️',
  sort_order  INT DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- PRODUCTS
-- ============================================================
CREATE TABLE products (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id     INT NOT NULL,
  category_id   INT,
  name          VARCHAR(150) NOT NULL,
  description   TEXT,
  price         DECIMAL(12,2) NOT NULL,
  stock         INT NOT NULL DEFAULT 0,
  stock_min     INT DEFAULT 5,
  is_available  TINYINT(1) DEFAULT 1,
  is_active     TINYINT(1) DEFAULT 1,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- RESTAURANT TABLES (Meja)
-- ============================================================
CREATE TABLE restaurant_tables (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  number      INT UNIQUE NOT NULL,
  label       VARCHAR(50),
  capacity    INT DEFAULT 4,
  is_occupied TINYINT(1) DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- SHIFTS
-- ============================================================
CREATE TABLE shifts (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  kasir_id        INT NOT NULL,
  status          ENUM('aktif','tutup') DEFAULT 'aktif',
  opening_cash    DECIMAL(12,2) DEFAULT 0,
  total_sales     DECIMAL(12,2) DEFAULT 0,
  total_orders    INT DEFAULT 0,
  actual_cash     DECIMAL(12,2),
  cash_difference DECIMAL(12,2),
  notes           TEXT,
  opened_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  closed_at       DATETIME,
  FOREIGN KEY (kasir_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ============================================================
-- ORDERS
-- ============================================================
CREATE TABLE orders (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  order_number    VARCHAR(30) UNIQUE NOT NULL,
  kasir_id        INT NOT NULL,
  shift_id        INT NOT NULL,
  table_id        INT,
  table_number    INT,
  status          ENUM('pending','diproses','selesai','dibatalkan') DEFAULT 'pending',
  payment_method  ENUM('tunai','qris','debit') DEFAULT 'tunai',
  subtotal        DECIMAL(12,2) DEFAULT 0,
  tax             DECIMAL(12,2) DEFAULT 0,
  total           DECIMAL(12,2) DEFAULT 0,
  amount_paid     DECIMAL(12,2) DEFAULT 0,
  change_amount   DECIMAL(12,2) DEFAULT 0,
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  completed_at    DATETIME,
  FOREIGN KEY (kasir_id) REFERENCES users(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id),
  FOREIGN KEY (table_id) REFERENCES restaurant_tables(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- ORDER ITEMS
-- ============================================================
CREATE TABLE order_items (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  order_id      INT NOT NULL,
  product_id    INT,
  tenant_id     INT,
  product_name  VARCHAR(150) NOT NULL,
  quantity      INT NOT NULL DEFAULT 1,
  unit_price    DECIMAL(12,2) NOT NULL,
  subtotal      DECIMAL(12,2) NOT NULL,
  status        ENUM('pending','diproses','selesai') DEFAULT 'pending',
  notes         TEXT,
  completed_at  DATETIME,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Users (password: kasir123 & admin123)
INSERT INTO users (username, password, full_name, role) VALUES
('kasir', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Budi Santoso', 'kasir'),
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin Warung', 'admin');

-- Note: password hash above is for 'password' — run setup.php to fix hashes

-- Tenants
INSERT INTO tenants (name, description, color) VALUES
('Tenant A - Kopi & Minuman', 'Minuman kopi dan non-kopi', '#059669'),
('Tenant B - Makanan Berat', 'Nasi dan lauk pauk', '#0284c7'),
('Tenant C - Snack & Dessert', 'Cemilan dan dessert', '#7c3aed');

-- Tenant users (password: tenant123)
INSERT INTO users (username, password, full_name, role, tenant_id) VALUES
('tenant.a', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PIC Tenant A', 'tenant', 1),
('tenant.b', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PIC Tenant B', 'tenant', 2),
('tenant.c', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PIC Tenant C', 'tenant', 3);

-- Categories
INSERT INTO categories (tenant_id, name, icon, sort_order) VALUES
(1, 'Kopi', '☕', 1),
(1, 'Non-Kopi', '🧃', 2),
(2, 'Nasi', '🍚', 1),
(2, 'Lauk', '🍗', 2),
(3, 'Snack', '🍪', 1),
(3, 'Dessert', '🍨', 2);

-- Products
INSERT INTO products (tenant_id, category_id, name, price, stock, stock_min, is_available) VALUES
(1, 1, 'Kopi Hitam', 8000, 50, 5, 1),
(1, 1, 'Kopi Susu', 15000, 40, 5, 1),
(1, 1, 'Cappuccino', 20000, 30, 5, 1),
(1, 1, 'Americano', 18000, 25, 5, 1),
(1, 2, 'Es Teh Manis', 5000, 60, 10, 1),
(1, 2, 'Jus Jeruk', 12000, 20, 5, 1),
(1, 2, 'Matcha Latte', 22000, 15, 5, 1),
(2, 3, 'Nasi Goreng', 18000, 30, 5, 1),
(2, 3, 'Nasi Uduk', 15000, 25, 5, 1),
(2, 4, 'Ayam Goreng', 20000, 20, 5, 1),
(2, 4, 'Tempe Orek', 8000, 35, 5, 1),
(2, 4, 'Mie Goreng', 15000, 20, 3, 1),
(3, 5, 'Pisang Goreng', 8000, 40, 5, 1),
(3, 5, 'Singkong Goreng', 7000, 30, 5, 1),
(3, 6, 'Es Krim Coklat', 15000, 15, 3, 1),
(3, 6, 'Pudding Mangga', 12000, 10, 3, 1);

-- Restaurant Tables
INSERT INTO restaurant_tables (number, label, capacity) VALUES
(1, 'Meja 1', 4), (2, 'Meja 2', 4), (3, 'Meja 3', 4),
(4, 'Meja 4', 2), (5, 'Meja 5', 2), (6, 'Meja 6', 6),
(7, 'Meja 7', 4), (8, 'Meja 8', 4), (9, 'Meja 9', 2),
(10, 'Meja 10', 6), (11, 'Meja 11', 4), (12, 'Meja 12', 4);
