// ============================================================
//  assets/js/app.js  — Warung Kuphi POS v2 (clean & responsive)
// ============================================================

// ── Global state ─────────────────────────────────────────────
const state = {
  user:        window.WK_USER || null,
  activeMenu:  'dashboard',
  activeShift: null,
  cart:        [],   // {id,name,price,qty,tenant_id,tenant_name,notes}
  flyoutOpen:  false,
};

// ── Helpers ──────────────────────────────────────────────────
const fmt = (n, sym = true) =>
  (sym ? 'Rp ' : '') + new Intl.NumberFormat('id-ID').format(n);

function pad(n) { return String(n).padStart(2, '0'); }

function dtId(s) {
  if (!s) return '-';
  const d = new Date(s);
  const m = ['','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'];
  return `${d.getDate()} ${m[d.getMonth()+1]} ${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function dtTime(s) {
  if (!s) return '-';
  const d = new Date(s);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function nowDt() {
  const d = new Date();
  const m = ['','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'];
  return `${d.getDate()} ${m[d.getMonth()+1]} ${d.getFullYear()}`;
}
function dateOnly(s) {
  const d = new Date(s);
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}

const STATUS = {
  pending:    { label:'Pending',    color:'#d97706', bg:'#fffbeb',  icon:'⏳' },
  diproses:   { label:'Diproses',   color:'#0284c7', bg:'#dbeafe',  icon:'🔄' },
  selesai:    { label:'Selesai',    color:'#059669', bg:'#d1fae5',  icon:'✅' },
  dibatalkan: { label:'Dibatalkan', color:'#ef4444', bg:'#fee2e2',  icon:'❌' },
};

// ── API ──────────────────────────────────────────────────────
const API_BASE = (window.WK_BASE || '') + '/api/';
async function api(action, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type':'application/json', 'Accept':'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(API_BASE + action, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request gagal');
  return data;
}

// ── Toast ────────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const ct = document.getElementById('toast-container');
  const t  = document.createElement('div');
  const icons = { success:'✅', error:'❌', info:'ℹ️', warning:'⚠️' };
  t.style.cssText = `
    background:#0f172a;color:#f8fafc;border-radius:10px;
    padding:11px 16px;font-size:13px;font-weight:500;
    box-shadow:0 8px 30px rgba(0,0,0,.28);pointer-events:auto;
    display:flex;align-items:center;gap:9px;min-width:220px;
    animation:_toast-in .3s cubic-bezier(.34,1.56,.64,1);
    font-family:'Plus Jakarta Sans',sans-serif;
  `;
  if (!document.getElementById('_ti')) {
    const s = document.createElement('style');
    s.id = '_ti';
    s.textContent = `@keyframes _toast-in{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}`;
    document.head.appendChild(s);
  }
  t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
  ct.appendChild(t);
  setTimeout(() => { t.style.transition='opacity .3s'; t.style.opacity='0'; setTimeout(() => t.remove(), 320); }, 3500);
}

// ── Cart ─────────────────────────────────────────────────────
function cartAdd(p) {
  const ex = state.cart.find(i => i.id === p.id);
  if (ex) { ex.qty++; } else { state.cart.push({ ...p, qty: 1, notes: '' }); }
  renderReceiptPanel();
}
function cartSetQty(id, qty) {
  if (qty <= 0) { state.cart = state.cart.filter(i => i.id !== id); }
  else { const i = state.cart.find(i => i.id === id); if (i) i.qty = qty; }
  renderReceiptPanel();
}
function cartSetNotes(id, notes) {
  const i = state.cart.find(i => i.id === id); if (i) i.notes = notes;
}
function cartClear() { state.cart = []; renderReceiptPanel(); }
function cartTotal() { return state.cart.reduce((s, i) => s + i.price * i.qty, 0); }

// ── Sidebar flyout ───────────────────────────────────────────
function toggleFlyout() {
  state.flyoutOpen = !state.flyoutOpen;
  document.getElementById('sidebar-flyout')?.classList.toggle('open', state.flyoutOpen);
  document.getElementById('sidebar-overlay')?.classList.toggle('active', state.flyoutOpen);
}
function closeFlyout() {
  state.flyoutOpen = false;
  document.getElementById('sidebar-flyout')?.classList.remove('open');
  document.getElementById('sidebar-overlay')?.classList.remove('active');
}

// ── Navigate ─────────────────────────────────────────────────
function navigate(menu) {
  state.activeMenu = menu;
  closeFlyout();

  document.querySelectorAll('.sidebar-icon-btn').forEach(el =>
    el.classList.toggle('active', el.dataset.menu === menu));
  document.querySelectorAll('.flyout-item').forEach(el =>
    el.classList.toggle('active', el.dataset.menu === menu));

  const titles = {
    dashboard:'Dashboard', pos:'Order POS',
    'active-orders':'Order Aktif', history:'Riwayat Transaksi',
    products:'Produk & Stok', shift:'Manajemen Shift',
  };
  const ht = document.getElementById('header-page-title');
  if (ht) ht.textContent = titles[menu] || '';

  const pc = document.getElementById('page-content');
  if (!pc) return;
  pc.innerHTML = '';
  pc.className = 'page-content page-enter';
  // reset any full-layer overrides from POS/payment
  pc.style.padding = '';
  pc.style.overflow = '';

  const renderers = {
    dashboard: renderDashboard,
    pos: renderPOS,
    'active-orders': renderActiveOrders,
    history: renderHistory,
    products: renderProducts,
    shift: renderShift,
  };
  (renderers[menu] || renderDashboard)(pc);
}

// ── App Shell ────────────────────────────────────────────────
function renderAppShell() {
  const root = document.getElementById('app-root');
  const user = state.user;
  const initials = (user.full_name || 'K').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

  const menuItems = [
    { key:'dashboard',      label:'Dashboard',    icon:'🏠' },
    { key:'pos',            label:'Order POS',    icon:'🛒' },
    { key:'active-orders',  label:'Order Aktif',  icon:'📋', badge:'active' },
    { key:'history',        label:'Riwayat',      icon:'📜' },
    { key:'products',       label:'Produk & Stok',icon:'📦', badge:'stock' },
    { key:'shift',          label:'Shift',        icon:'⏰' },
  ];

  root.innerHTML = `
    <div class="app-layout">

      <!-- Sidebar icon strip -->
      <aside class="sidebar" style="background: #073500;">
        <div class="sidebar-logo-area" onclick="toggleFlyout()" title="Buka Menu">
          <div class="sidebar-logo-icon">☕</div>
        </div>
        <nav class="sidebar-nav-icons">
          ${menuItems.map(m => `
            <button class="sidebar-icon-btn ${state.activeMenu === m.key ? 'active' : ''}"
              data-menu="${m.key}" onclick="navigate('${m.key}')" title="${m.label}">
              <div class="sidebar-icon-inner">${m.icon}</div>
              ${m.badge === 'active' ? `<span id="icon-badge-active" class="sidebar-badge-dot" style="display:none"></span>` : ''}
              ${m.badge === 'stock'  ? `<span id="icon-badge-stock"  class="sidebar-badge-dot" style="display:none"></span>` : ''}
            </button>
          `).join('')}
        </nav>
        <div class="sidebar-footer-icon">
          <div class="sidebar-avatar-btn" onclick="doLogout()" title="${user.full_name} — Logout">
            <div class="sidebar-avatar">${initials}</div>
          </div>
        </div>
      </aside>

      <!-- Flyout panel -->
      <div id="sidebar-flyout" class="sidebar-flyout">
        <div class="flyout-logo-area">
          <div class="sidebar-logo-icon" style="width:28px;height:28px;font-size:13px;flex-shrink:0">☕</div>
          <div>
            <div class="flyout-logo-name">Warung Kuphi</div>
            <div class="flyout-logo-sub">POS System</div>
          </div>
        </div>
        <nav class="flyout-nav">
          <div class="flyout-section-label">Menu Utama</div>
          ${menuItems.map(m => `
            <div class="flyout-item ${state.activeMenu === m.key ? 'active' : ''}"
              data-menu="${m.key}" onclick="navigate('${m.key}')">
              <span class="flyout-item-icon">${m.icon}</span>
              <span>${m.label}</span>
              ${m.badge === 'active' ? `<span id="flyout-badge-active" class="flyout-item-badge" style="display:none"></span>` : ''}
              ${m.badge === 'stock'  ? `<span id="flyout-badge-stock"  class="flyout-item-badge warning" style="display:none"></span>` : ''}
            </div>
          `).join('')}
          <div id="flyout-shift-pill"></div>
        </nav>
        <div class="flyout-footer">
          <div class="flyout-user" onclick="doLogout()">
            <div class="sidebar-avatar">${initials}</div>
            <div class="flyout-user-info">
              <div class="flyout-user-name">${user.full_name}</div>
              <div class="flyout-user-role">${user.role} · Logout ↩</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Click-away overlay -->
      <div id="sidebar-overlay" class="sidebar-overlay" onclick="closeFlyout()"></div>

      <!-- Main content -->
      <div class="main-content">
        <header class="header">
          <div style="flex:1">
            <div class="header-title" id="header-page-title">Dashboard</div>
          </div>
          <div class="header-actions">
            <div id="header-clock" class="header-clock"></div>
            <div id="header-shift-pill"></div>
            <button class="header-icon-btn" title="Notifikasi">
              🔔<span id="notif-dot" class="header-notif-dot" style="display:none"></span>
            </button>
          </div>
        </header>
        <div class="page-content page-enter" id="page-content"></div>
      </div>
    </div>
  `;

  // Live clock
  function tick() {
    const el = document.getElementById('header-clock');
    if (el) el.textContent = new Date().toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  }
  tick(); setInterval(tick, 1000);

  navigate('dashboard');
}

function doLogout() { window.location.href = (window.WK_BASE || '') + '/logout'; }

// ── Shift UI refresh ──────────────────────────────────────────
function updateShiftUI() {
  const shift = state.activeShift;

  const hp = document.getElementById('header-shift-pill');
  if (hp) {
    if (shift) {
      const ms = Date.now() - new Date(shift.opened_at);
      const h  = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
      hp.innerHTML = `<button class="shift-status-pill active" onclick="navigate('shift')">
        <span class="shift-dot" style="animation:pulse-green 2s infinite"></span>Shift ${h}j ${m}m</button>`;
    } else {
      hp.innerHTML = `<button class="shift-status-pill inactive" onclick="navigate('shift')">
        <span class="shift-dot"></span>Buka Shift</button>`;
    }
  }

  const fp = document.getElementById('flyout-shift-pill');
  if (fp) {
    fp.innerHTML = shift
      ? `<div class="flyout-shift-pill active" onclick="navigate('shift')">
           <span class="shift-dot" style="animation:pulse-green 2s infinite"></span>Shift Aktif</div>`
      : `<div class="flyout-shift-pill inactive" onclick="navigate('shift')">
           <span class="shift-dot"></span>Shift Tutup</div>`;
  }
}

// ── Badge helpers ─────────────────────────────────────────────
function setBadge(id, count) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.display = count > 0 ? '' : 'none';
  if (el.textContent !== undefined && el.tagName !== 'SPAN' || el.className.includes('flyout')) {
    el.textContent = count;
  }
}

// ─────────────────────────────────────────────────────────────
//  DASHBOARD
// ─────────────────────────────────────────────────────────────
async function renderDashboard(el) {
  el.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;
  try {
    const { today_sales, active_orders, stock_alerts, recent_orders } = await api('dashboard.stats');
    const outOfStock = stock_alerts.filter(p => p.stock == 0);
    const lowStock   = stock_alerts.filter(p => p.stock > 0 && p.stock <= p.stock_min);

    // Badges
    if (active_orders > 0) {
      document.getElementById('icon-badge-active')?.style && (document.getElementById('icon-badge-active').style.display = '');
      const fb = document.getElementById('flyout-badge-active');
      if (fb) { fb.style.display = ''; fb.textContent = active_orders; }
    }
    if (stock_alerts.length > 0) {
      document.getElementById('icon-badge-stock')?.style && (document.getElementById('icon-badge-stock').style.display = '');
      const fsb = document.getElementById('flyout-badge-stock');
      if (fsb) { fsb.style.display = ''; fsb.textContent = stock_alerts.length; }
    }

    el.innerHTML = `
      <div class="page-header">
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">${new Date().toLocaleDateString('id-ID',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
      </div>
      <div class="stats-grid">
        ${statCard('💰','Penjualan Hari Ini',fmt(today_sales),'Dari transaksi selesai','#059669','#ecfdf5','history')}
        ${statCard('📋','Order Aktif',active_orders,'Pending & Diproses','#0284c7','#f0f9ff','active-orders')}
        ${statCard('⚠️','Stok Habis',outOfStock.length,outOfStock.length?'Perlu restock segera':'Semua stok aman',outOfStock.length?'#dc2626':'#059669',outOfStock.length?'#fef2f2':'#ecfdf5','products')}
        ${statCard('📉','Stok Menipis',lowStock.length,lowStock.length?'Segera tambah stok':'Stok aman',lowStock.length?'#d97706':'#059669',lowStock.length?'#fffbeb':'#ecfdf5','products')}
      </div>
      <div style="display:grid;grid-template-columns:1fr minmax(0,300px);gap:16px;align-items:start">
        <!-- Recent orders -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Order Terbaru</div>
            <button class="btn btn-ghost btn-sm" onclick="navigate('active-orders')">Lihat Semua →</button>
          </div>
          ${recent_orders.length === 0
            ? `<div class="empty-state"><div class="empty-state-icon">📋</div><div class="empty-state-title">Belum ada order</div></div>`
            : `<div style="overflow-x:auto"><table class="data-table"><thead><tr>
                <th>#</th><th>Order</th><th>Meja</th><th>Kasir</th><th>Total</th><th>Status</th><th>Waktu</th>
               </tr></thead><tbody>
               ${recent_orders.map(o => {
                const st = STATUS[o.status] || {};
                return `<tr>
                  <td style="color:var(--text-4);font-size:12px">${o.seq_today||'-'}</td>
                  <td><span style="font-weight:700;font-size:13px">${o.order_number}</span></td>
                  <td>Meja ${o.table_number||'-'}</td>
                  <td>${o.profiles?.full_name||o.full_name||'-'}</td>
                  <td style="font-weight:700;color:var(--primary)">${fmt(o.total)}</td>
                  <td><span class="badge" style="background:${st.bg};color:${st.color}">${st.icon} ${st.label}</span></td>
                  <td style="color:var(--text-3);font-size:12px">${dtId(o.created_at)}</td>
                </tr>`;
               }).join('')}
               </tbody></table></div>`}
        </div>

        <!-- Stock alerts -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">⚠️ Notif Stok</div>
            <button class="btn btn-ghost btn-sm" onclick="navigate('products')">Detail →</button>
          </div>
          ${stock_alerts.length === 0
            ? `<div class="empty-state" style="padding:28px"><div class="empty-state-icon">✅</div><div class="empty-state-title" style="font-size:13px">Semua stok aman</div></div>`
            : `<div>
                ${outOfStock.length?`<div style="padding:8px 14px 2px;font-size:10.5px;font-weight:700;color:var(--danger);text-transform:uppercase;letter-spacing:.06em">HABIS (${outOfStock.length})</div>${outOfStock.map(p=>stockAlertItem(p,'danger')).join('')}`:''}
                ${lowStock.length?`<div style="padding:8px 14px 2px;font-size:10.5px;font-weight:700;color:var(--warning);text-transform:uppercase;letter-spacing:.06em">MENIPIS (${lowStock.length})</div>${lowStock.map(p=>stockAlertItem(p,'warning')).join('')}`:''}
              </div>`}
        </div>
      </div>
    `;
  } catch(e) {
    el.innerHTML = `<div class="empty-state"><div class="empty-state-icon">❌</div><div class="empty-state-title">${e.message}</div></div>`;
  }
}

function statCard(icon, label, value, sub, color, bg, menu) {
  return `<div class="stat-card" onclick="navigate('${menu}')">
    <div class="stat-card-icon" style="background:${bg};color:${color}">${icon}</div>
    <div class="stat-card-label">${label}</div>
    <div class="stat-card-value" style="color:${color}">${value}</div>
    <div class="stat-card-sub">${sub}</div>
    <div class="stat-card-accent" style="background:${color}"></div>
  </div>`;
}

function stockAlertItem(p, type) {
  const c   = type === 'danger' ? 'var(--danger)' : 'var(--warning)';
  const cbg = type === 'danger' ? 'var(--danger-pale)' : 'var(--warning-pale)';
  const pct = Math.min(100, (p.stock / (p.stock_min * 3 || 15)) * 100);
  return `<div style="padding:9px 14px;border-bottom:1px solid var(--border-light)">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:13px;font-weight:600">${p.name}</span>
      <span style="font-size:11.5px;font-weight:700;color:${c};background:${cbg};padding:2px 8px;border-radius:10px">
        ${p.stock == 0 ? 'HABIS' : 'Sisa ' + p.stock}
      </span>
    </div>
    <div style="font-size:11px;color:var(--text-4)">${p.tenants?.name||''}</div>
    ${p.stock > 0 ? `<div class="stock-bar"><div class="stock-bar-fill" style="width:${pct}%;background:${c}"></div></div>` : ''}
  </div>`;
}

// ─────────────────────────────────────────────────────────────
//  POS
// ─────────────────────────────────────────────────────────────
async function renderPOS(pc) {
  if (!state.activeShift) {
    pc.innerHTML = `<div class="empty-state" style="margin-top:80px">
      <div class="empty-state-icon">⏰</div>
      <div class="empty-state-title">Shift Belum Dibuka</div>
      <div class="empty-state-desc">Buka shift terlebih dahulu untuk mulai membuat order</div>
      <button class="btn btn-primary" style="margin-top:16px" onclick="navigate('shift')">Buka Shift Sekarang →</button>
    </div>`;
    return;
  }

  // Full-layer override
  pc.style.padding  = '0';
  pc.style.overflow = 'hidden';

  pc.innerHTML = `
    <div class="pos-layout">
      <div class="pos-left" id="pos-left">
        <div class="pos-steps" id="pos-steps"></div>
        <div id="pos-step-content" style="flex:1;overflow:hidden;display:flex;flex-direction:column;margin-top:12px"></div>
      </div>
      <div class="receipt-panel">
        <div class="receipt-header">
          <div class="receipt-header-icon">📄</div>
          <div class="receipt-title">Struk Pesanan</div>
        </div>
        <div class="receipt-scroll" id="receipt-scroll"></div>
        <div class="receipt-footer" id="receipt-footer"></div>
      </div>
    </div>
  `;

  // POS local state (accessible via window._pos)
  const pos = { step: 'products', products: [], selectedTable: null };
  window._pos = pos;

  // ── Steps bar ──────────────────────────────────────────────
  function drawSteps() {
    const bar   = document.getElementById('pos-steps');
    if (!bar) return;
    const steps = [{ key:'products', label:'1. Pilih Produk' }, { key:'table', label:'2. Pilih Meja' }];
    const ci    = steps.findIndex(s => s.key === pos.step);
    bar.innerHTML = steps.map((s, i) => `
      <div class="pos-step-pill ${s.key===pos.step?'active':i<ci?'done':'pending'}"
        ${i < ci ? `onclick="window._pos.step='${s.key}';renderPOSStep()"` : ''}>
        ${s.label}
      </div>
      ${i < steps.length-1 ? `<span class="pos-step-arrow">→</span>` : ''}
    `).join('');
  }

  function renderStep() {
    drawSteps();
    const c = document.getElementById('pos-step-content');
    if (!c) return;
    if (pos.step === 'products') renderProductStep(c);
    else renderTableStep(c);
  }
  window.renderPOSStep = renderStep;

  // ── Step 1 — Products ─────────────────────────────────────
  function renderProductStep(c) {
    if (!c._search)    c._search    = '';
    if (!c._filterTen) c._filterTen = 'all';
    const search    = c._search;
    const filterTen = c._filterTen;

    const tenants = [...new Map(pos.products.map(p => [p.tenant_id, p.tenants])).entries()]
      .map(([id, t]) => ({ id, ...t }));

    const filtered = pos.products.filter(p => {
      const mt = filterTen === 'all' || p.tenant_id == filterTen;
      const ms = p.name.toLowerCase().includes(search.toLowerCase());
      return mt && ms && p.is_available != 0;
    });

    const grouped = {};
    filtered.forEach(p => {
      if (!grouped[p.tenant_id]) grouped[p.tenant_id] = { tenant: p.tenants, items: [] };
      grouped[p.tenant_id].items.push(p);
    });

    c.innerHTML = `
      <div style="display:flex;gap:10px;margin-bottom:10px;flex-shrink:0">
        <div style="position:relative;flex:1">
          <span style="position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:13px">🔍</span>
          <input class="form-input" id="pos-search" style="padding-left:34px;height:40px"
            placeholder="Cari produk..." value="${search}">
        </div>
        <select class="form-input form-select" id="pos-ten" style="width:160px;height:40px">
          <option value="all">Semua Tenant</option>
          ${tenants.map(t => `<option value="${t.id}" ${filterTen==t.id?'selected':''}>${t.name}</option>`).join('')}
        </select>
      </div>
      <div class="pos-products-area" id="pos-product-list">
        ${Object.values(grouped).length === 0
          ? `<div class="empty-state"><div class="empty-state-icon">🔍</div><div class="empty-state-title">Tidak ditemukan</div></div>`
          : Object.values(grouped).map(({ tenant, items }) => `
            <div style="margin-bottom:20px">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid var(--border)">
                <div style="width:7px;height:22px;border-radius:4px;background:${tenant?.color||'var(--primary)'}"></div>
                <span style="font-size:13.5px;font-weight:700">${tenant?.name||''}</span>
                <span style="font-size:12px;color:var(--text-4)">${items.length} produk</span>
              </div>
              <div class="product-grid">
                ${items.map(p => {
                  const inCart = state.cart.find(i => i.id == p.id);
                  const oos    = p.stock == 0;
                  return `
                    <div class="product-card ${oos?'out-of-stock':''} ${inCart?'in-cart':''}"
                      onclick="${!oos?`_posAdd(${p.id})`:''}"
                      style="${oos?'pointer-events:none':''}">
                      <div class="product-card-emoji">${p.category_icon||'🍽️'}</div>
                      <div class="product-card-name">${p.name}</div>
                      <div class="product-card-price">${fmt(p.price)}</div>
                      <div style="display:flex;justify-content:space-between;align-items:center">
                        <span class="product-card-stock">Stok: ${p.stock}</span>
                        ${oos ? `<span class="badge badge-danger" style="font-size:9.5px">HABIS</span>` : ''}
                      </div>
                      ${inCart ? `
                        <div class="product-cart-controls" onclick="event.stopPropagation()">
                          <button class="cart-qty-btn minus" onclick="cartSetQty(${p.id},${inCart.qty-1});if(window.renderPOSStep)renderPOSStep()">−</button>
                          <span class="cart-qty-num">${inCart.qty}</span>
                          <button class="cart-qty-btn plus" onclick="cartSetQty(${p.id},${inCart.qty+1});if(window.renderPOSStep)renderPOSStep()">+</button>
                        </div>
                        <input class="product-note-input" placeholder="Catatan (opsional)..."
                          value="${(inCart.notes||'').replace(/"/g,'&quot;')}"
                          onclick="event.stopPropagation()"
                          oninput="cartSetNotes(${p.id},this.value)">
                      ` : ''}
                    </div>`;
                }).join('')}
              </div>
            </div>
          `).join('')}
      </div>
    `;

    document.getElementById('pos-search')?.addEventListener('input', e => { c._search = e.target.value; renderProductStep(c); });
    document.getElementById('pos-ten')?.addEventListener('change', e => { c._filterTen = e.target.value; renderProductStep(c); });

    window._posAdd = (pid) => {
      const p = pos.products.find(pr => pr.id == pid);
      if (!p) return;
      cartAdd({ id:p.id, name:p.name, price:parseFloat(p.price), tenant_id:p.tenant_id, tenant_name:p.tenants?.name||'' });
      renderProductStep(c);
    };
  }

  // ── Step 2 — Tables ───────────────────────────────────────
  function renderTableStep(c) {
    c.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;
    api('tables.list').then(({ tables }) => {
      c.innerHTML = `
        <div style="margin-bottom:12px;flex-shrink:0">
          <div style="font-size:14px;font-weight:700;margin-bottom:6px">Pilih Meja</div>
          <div style="font-size:12px;color:var(--text-3);display:flex;gap:14px">
            <span style="display:inline-flex;align-items:center;gap:5px">
              <span style="width:10px;height:10px;border-radius:2px;background:var(--emerald-100);border:2px solid var(--primary);display:inline-block"></span>Tersedia
            </span>
            <span style="display:inline-flex;align-items:center;gap:5px">
              <span style="width:10px;height:10px;border-radius:2px;background:#fef3c7;border:2px solid #fbbf24;display:inline-block"></span>Terisi
            </span>
          </div>
        </div>
        <div class="table-grid" style="overflow-y:auto;flex:1;align-content:start">
          ${tables.map(t => `
            <div class="table-cell ${t.is_occupied==1?'occupied':''} ${pos.selectedTable?.id===t.id?'selected':''}"
              onclick="${t.is_occupied!=1?`_posSelTable(${t.id},${t.number})`:''}">
              <span style="font-size:18px">🪑</span>
              <span>${t.number}</span>
              ${t.is_occupied==1 ? `<span style="font-size:8.5px;opacity:.6">TERISI</span>` : `<span style="font-size:9.5px;color:var(--text-4)">${t.capacity} org</span>`}
            </div>
          `).join('')}
        </div>
        <div style="margin-top:12px;flex-shrink:0">
          <button class="btn btn-secondary" onclick="window._pos.step='products';renderPOSStep()">← Kembali</button>
        </div>
      `;
      window._posSelTable = (id, number) => {
        pos.selectedTable = { id, number };
        renderTableStep(c);
        renderReceiptPanel();
      };
    });
  }

  // Load products then render
  api('products.list').then(({ products }) => {
    pos.products = products;
    renderStep();
  });
  renderReceiptPanel();
}

// ── Receipt panel (dark sidebar) ─────────────────────────────
function renderReceiptPanel() {
  const scroll = document.getElementById('receipt-scroll');
  const footer = document.getElementById('receipt-footer');
  if (!scroll || !footer) return;

  const pos    = window._pos || {};
  const items  = state.cart;
  const total  = cartTotal();
  const now    = new Date();

  if (items.length === 0) {
    scroll.innerHTML = `
      <div class="receipt-empty">
        <div class="receipt-empty-icon">🛒</div>
        Belum ada produk<br>dipilih
      </div>`;
    footer.innerHTML = `<button class="btn-create-order" disabled>Buat Pesanan</button>`;
    return;
  }

  scroll.innerHTML = `
    <div class="receipt-paper">
      <div class="receipt-shop-name">☕ WARUNG KUPHI</div>
      <div class="receipt-shop-sub">Struk Sementara</div>
      <hr class="receipt-divider">
      <div class="receipt-meta"><span>Tanggal</span><span>${nowDt()}</span></div>
      <div class="receipt-meta"><span>Jam</span><span>${pad(now.getHours())}:${pad(now.getMinutes())}</span></div>
      <div class="receipt-meta">
        <span>Meja</span>
        <span style="${pos.selectedTable?'font-weight:700;color:var(--primary)':'color:var(--text-4)'}">
          ${pos.selectedTable ? 'No. ' + pos.selectedTable.number : 'Belum dipilih'}
        </span>
      </div>
      <hr class="receipt-divider">
      ${items.map(item => `
        <div class="receipt-item-row">
          <div style="flex:1">
            <div class="receipt-item-name">${item.name}</div>
            ${item.notes ? `<div class="receipt-item-note">* ${item.notes}</div>` : ''}
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:1px">
            <div class="receipt-item-qty">${item.qty}×${fmt(item.price, false)}</div>
            <div class="receipt-item-price">${fmt(item.price * item.qty)}</div>
          </div>
        </div>
      `).join('')}
      <hr class="receipt-divider">
      <div class="receipt-total-row">
        <div class="receipt-total-label">TOTAL</div>
        <div class="receipt-total-value">${fmt(total)}</div>
      </div>
      <div style="font-size:9px;color:var(--text-4);text-align:center;margin-top:6px">— pembayaran di order aktif —</div>
    </div>
  `;

  footer.innerHTML = `
    <button class="btn-receipt-print" onclick="printTempReceipt()">🖨️ Cetak Struk Sementara</button>
    ${pos.selectedTable
      ? `<button class="btn-create-order" onclick="doBuatPesanan()">✅ Buat Pesanan — Meja ${pos.selectedTable.number}</button>`
      : `<button class="btn-create-order" onclick="window._pos.step='table';renderPOSStep&&renderPOSStep()">🪑 Pilih Meja Dulu</button>`}
  `;
}

// ── Print temp receipt ────────────────────────────────────────
function printTempReceipt() {
  const pos = window._pos || {};
  const now = new Date();
  const line = '─'.repeat(32);
  const ctr  = t => t.padStart(Math.floor((32 + t.length) / 2)).padEnd(32);
  const rows = [
    ctr('WARUNG KUPHI'), ctr('--- Struk Sementara ---'), line,
    `Tanggal : ${nowDt()}`,
    `Jam     : ${pad(now.getHours())}:${pad(now.getMinutes())}`,
    `Meja    : ${pos.selectedTable ? pos.selectedTable.number : '-'}`,
    line,
  ];
  state.cart.forEach(i => {
    rows.push(`${i.name.substring(0,18).padEnd(18)}${String(i.qty+'x').padStart(4)}${fmt(i.price*i.qty).padStart(12)}`);
    if (i.notes) rows.push(`  * ${i.notes}`);
  });
  rows.push(line, `${'TOTAL'.padEnd(22)}${fmt(cartTotal()).padStart(10)}`, line, ctr('** BELUM LUNAS **'));
  const w = window.open('', '_blank', 'width=400,height=600');
  w.document.write(`<html><head><title>Struk Sementara</title>
    <style>body{font-family:monospace;font-size:12px;padding:16px;white-space:pre}
    @media print{@page{margin:0}body{margin:8px}}</style></head>
    <body onload="print();close()">${rows.join('\n')}</body></html>`);
  w.document.close();
}

// ── Submit order ──────────────────────────────────────────────
async function doBuatPesanan() {
  const pos = window._pos || {};
  if (!pos.selectedTable) { toast('Pilih meja terlebih dahulu', 'error'); return; }
  if (!state.cart.length) { toast('Keranjang kosong', 'error'); return; }

  const btn = document.querySelector('.btn-create-order');
  if (btn) { btn.disabled = true; btn.textContent = 'Membuat pesanan...'; }

  try {
    const r = await api('orders.create', 'POST', {
      cart_items:   state.cart.map(i => ({ id:i.id, name:i.name, price:i.price, quantity:i.qty, tenant_id:i.tenant_id, notes:i.notes||'' })),
      table_id:     pos.selectedTable.id,
      table_number: pos.selectedTable.number,
    });
    toast(`✅ Pesanan #${r.seq_today} berhasil dibuat!`, 'success');
    cartClear();
    pos.step = 'products'; pos.selectedTable = null;
    if (window.renderPOSStep) renderPOSStep();
  } catch(e) {
    toast(e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Buat Pesanan'; }
  }
}

// ─────────────────────────────────────────────────────────────
//  ORDER AKTIF
// ─────────────────────────────────────────────────────────────
async function renderActiveOrders(pc) {
  pc.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;

  let tab            = 'pending';
  let orders         = [];
  let selesaiOrders  = [];
  let selesaiLoaded  = false;
  let expandedId     = null;

  // Store el reference on window so onclick handlers can reach it
  window._aoEl = pc;

  async function load()        { const d = await api('orders.active');  orders = d.orders; draw(); }
  async function loadSelesai() { if (selesaiLoaded) return; const d = await api('orders.selesai'); selesaiOrders = d.orders; selesaiLoaded = true; }

  async function setTab(t) {
    tab = t;
    if (t === 'selesai') await loadSelesai();
    draw();
  }

  function draw() {
    const pending  = orders.filter(o => o.status === 'pending');
    const diproses = orders.filter(o => o.status === 'diproses');
    const display  = tab === 'pending' ? pending : tab === 'diproses' ? diproses : selesaiOrders;

    pc.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div>
          <div class="page-title">Order Aktif</div>
          <div class="page-subtitle">Monitor & kelola pesanan secara real-time</div>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="window._aoRefresh()">⟳ Refresh</button>
      </div>
      <div class="tabs">
        ${[
          { key:'pending',  label:'Pending',         icon:'⏳', color:'#d97706', count:pending.length },
          { key:'diproses', label:'Diproses',        icon:'🔄', color:'#0284c7', count:diproses.length },
          { key:'selesai',  label:'Selesai Hari Ini',icon:'✅', color:'#059669', count:selesaiOrders.length },
        ].map(t => `
          <button class="tab-btn ${tab===t.key?'active':''}" onclick="window._aoTab('${t.key}')">
            ${t.icon} ${t.label}
            ${t.count > 0 ? `<span style="background:${t.color};color:white;border-radius:10px;font-size:10px;font-weight:700;padding:1px 7px">${t.count}</span>` : ''}
          </button>
        `).join('')}
      </div>
      ${display.length === 0
        ? `<div class="empty-state">
            <div class="empty-state-icon">${tab==='pending'?'⏳':tab==='diproses'?'🔄':'✅'}</div>
            <div class="empty-state-title">${
              tab==='pending'  ? 'Tidak ada order pending' :
              tab==='diproses' ? 'Tidak ada order diproses' :
              'Belum ada order selesai hari ini'
            }</div>
           </div>`
        : `<div class="orders-grid">${display.map(o => orderCard(o, tab==='selesai', expandedId===o.id)).join('')}</div>`}
    `;

    // Register window handlers
    window._aoTab     = async t => { await setTab(t); };
    window._aoRefresh = async () => { await load(); selesaiLoaded = false; if (tab==='selesai') await loadSelesai(); draw(); };
    window._aoExpand  = id => { expandedId = expandedId===id ? null : id; draw(); };
    window._aoSelesaikan = id => {
      const order = orders.find(o => o.id == id) || selesaiOrders.find(o => o.id == id);
      if (order) renderPaymentPage(pc, order, () => { pc.style.padding=''; pc.style.overflow=''; load(); });
    };
  }

  await load();
}

function orderCard(order, readOnly, expanded) {
  const st       = STATUS[order.status] || {};
  const items    = order.order_items || [];
  const seqNum   = order.seq_today || '?';
  const oTime    = dtTime(order.created_at);

  return `
    <div class="order-card ${expanded?'expanded':''} fade-in" onclick="_aoExpand(${order.id})">
      <div class="order-card-head">
        <div style="display:flex;align-items:center;gap:10px;flex:1">
          <div class="order-num-badge">${seqNum}</div>
          <div>
            <div class="order-card-title">Meja ${order.table_number||'-'}</div>
            <div class="order-card-meta">${oTime} · ${order.profiles?.full_name||''} · ${order.order_number}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="badge" style="background:${st.bg};color:${st.color}">${st.icon} ${st.label}</span>
          <span style="font-size:11px;color:var(--text-4)">${expanded?'▲':'▼'}</span>
        </div>
      </div>

      ${expanded ? `
        <div class="order-card-body">
          ${items.length === 0
            ? `<div style="padding:8px 0;color:var(--text-3);font-size:13px">Tidak ada item</div>`
            : items.map(item => `
              <div class="order-item-line">
                <div style="flex:1">
                  <div class="order-item-name">${item.product_name}</div>
                  ${item.notes ? `<div class="order-item-note">📌 ${item.notes}</div>` : ''}
                  <div style="font-size:10.5px;color:var(--text-4)">${item.tenants?.name||''}</div>
                </div>
                <div style="display:flex;align-items:center;gap:10px">
                  <span class="order-item-qty">×${item.quantity}</span>
                  <span class="order-item-sub">${fmt(item.subtotal)}</span>
                </div>
              </div>
            `).join('')}
        </div>
        <div class="order-card-foot">
          <div>
            <div style="font-size:12px;color:var(--text-3)">${items.length} item</div>
            <div style="font-size:17px;font-weight:800;color:var(--text-1)">${fmt(order.total)}</div>
          </div>
          ${!readOnly
            ? `<button class="btn-selesaikan" onclick="event.stopPropagation();_aoSelesaikan(${order.id})">💳 Selesaikan Pesanan</button>`
            : `<span class="badge badge-success" style="font-size:12px">✅ Lunas · ${dtTime(order.completed_at)}</span>`}
        </div>
      ` : `
        <div class="order-card-foot" style="padding:8px 16px">
          <div style="font-size:12px;color:var(--text-3)">
            ${items.slice(0,2).map(i=>i.product_name).join(', ')}${items.length>2?` +${items.length-2} lagi`:''}
          </div>
          <div style="font-size:15px;font-weight:800;color:var(--primary)">${fmt(order.total)}</div>
        </div>
      `}
    </div>
  `;
}

// ─────────────────────────────────────────────────────────────
//  PAYMENT PAGE
// ─────────────────────────────────────────────────────────────
function renderPaymentPage(pc, order, onBack) {
  pc.style.padding  = '0';
  pc.style.overflow = '';   // let inner payment-left handle its own scroll

  const items  = order.order_items || [];
  const total  = parseFloat(order.total);

  let payMethod   = 'tunai';
  let amountPaid  = '';

  // Store callback on window so onclick strings can call it
  window._payBack = () => { onBack(); };

  function draw() {
    const paid   = parseFloat(amountPaid) || 0;
    const change = paid - total;
    const canPay = payMethod !== 'tunai' || (amountPaid !== '' && paid >= total);

    pc.innerHTML = `
      <div class="payment-page">

        <!-- Left: form -->
        <div class="payment-left">
          <!-- Back + title -->
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:4px">
            <button class="btn btn-secondary btn-sm" onclick="window._payBack()">← Kembali</button>
            <div>
              <div class="page-title">Pembayaran</div>
              <div class="page-subtitle">Meja ${order.table_number} · #${order.seq_today||''} · ${order.order_number}</div>
            </div>
          </div>

          <!-- Order summary -->
          <div class="card card-padded">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <div style="font-size:13.5px;font-weight:700">Rincian Pesanan</div>
              <div style="font-size:12px;color:var(--text-3)">${dtId(order.created_at)}</div>
            </div>
            ${items.map(item => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-light)">
                <div>
                  <div style="font-size:13px;font-weight:500">${item.product_name} ×${item.quantity}</div>
                  ${item.notes ? `<div style="font-size:11px;color:var(--text-4);font-style:italic">📌 ${item.notes}</div>` : ''}
                  <div style="font-size:11px;color:var(--text-4)">${item.tenants?.name||''}</div>
                </div>
                <div style="font-size:13px;font-weight:600;color:var(--primary)">${fmt(item.subtotal)}</div>
              </div>
            `).join('')}
            <div style="display:flex;justify-content:space-between;align-items:center;padding-top:12px;margin-top:4px">
              <div style="font-size:15px;font-weight:700">Total</div>
              <div style="font-size:22px;font-weight:800;color:var(--primary)">${fmt(total)}</div>
            </div>
          </div>

          <!-- Method -->
          <div class="card card-padded">
            <div style="font-size:13.5px;font-weight:700;margin-bottom:12px">Metode Pembayaran</div>
            <div class="payment-method-grid">
              ${[{key:'tunai',label:'Tunai',icon:'💵'},{key:'qris',label:'QRIS',icon:'📱'},{key:'debit',label:'Debit / Kartu',icon:'💳'}].map(pm=>`
                <button class="pay-method-btn ${payMethod===pm.key?'selected':''}" onclick="window._payMethod('${pm.key}')">
                  <div class="pay-method-icon">${pm.icon}</div>
                  <div class="pay-method-label">${pm.label}</div>
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Tunai input -->
          ${payMethod === 'tunai' ? `
            <div class="card card-padded">
              <div style="font-size:13.5px;font-weight:700;margin-bottom:12px">Jumlah Bayar</div>
              <input class="form-input" type="number" id="pay-amount"
                placeholder="Masukkan jumlah uang..." value="${amountPaid}"
                style="font-size:18px;font-weight:700;text-align:right;margin-bottom:10px">
              <!-- Quick amounts -->
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
                ${[...new Set([total, Math.ceil(total/10000)*10000, Math.ceil(total/50000)*50000, 100000].filter(v=>v>=total))].slice(0,4)
                  .map(amt=>`<button class="btn btn-secondary btn-sm" onclick="window._paySetAmt(${amt})">${fmt(amt,false)}</button>`).join('')}
              </div>
              ${amountPaid !== '' ? `
                <div class="change-display ${change>=0?'positive':'negative'}">
                  <div class="change-label">Kembalian</div>
                  <div class="change-value ${change>=0?'positive':'negative'}">
                    ${change >= 0 ? fmt(change) : 'Kurang ' + fmt(Math.abs(change))}
                  </div>
                </div>
              ` : ''}
            </div>
          ` : payMethod === 'qris' ? `
            <div class="card card-padded" style="text-align:center">
              <div style="font-size:36px;margin-bottom:8px">📱</div>
              <div style="font-size:14px;font-weight:600">Scan QR untuk pembayaran</div>
              <div style="font-size:13px;color:var(--text-3);margin-top:4px">Total: <strong style="color:var(--primary)">${fmt(total)}</strong></div>
              <div style="margin:16px auto;padding:40px;background:var(--surface2);border-radius:var(--radius);display:inline-block;border:2px dashed var(--border)">
                <div style="font-size:11px;color:var(--text-4)">[QR Code Merchant]</div>
              </div>
              <div style="font-size:12px;color:var(--text-3)">Klik Konfirmasi setelah pembeli scan & bayar</div>
            </div>
          ` : `
            <div class="card card-padded" style="text-align:center">
              <div style="font-size:36px;margin-bottom:8px">💳</div>
              <div style="font-size:14px;font-weight:600">Masukkan kartu ke mesin EDC</div>
              <div style="font-size:13px;color:var(--text-3);margin-top:4px">Total: <strong style="color:var(--primary)">${fmt(total)}</strong></div>
              <div style="margin-top:12px;font-size:12px;color:var(--text-3)">Klik Konfirmasi setelah transaksi EDC berhasil</div>
            </div>
          `}

          <button id="btn-pay" class="btn-pay-confirm" ${!canPay?'disabled':''} onclick="window._payConfirm()">
            ✅ Konfirmasi Pembayaran — ${fmt(total)}
          </button>
        </div>

        <!-- Right: receipt preview -->
        <div class="payment-right">
          <div style="padding:14px 16px 10px;border-bottom:1px solid rgba(255,255,255,.08);flex-shrink:0">
            <div style="font-size:11px;font-weight:700;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.1em">📄 Preview Struk</div>
          </div>
          <div class="payment-order-summary">
            <div class="receipt-paper" style="margin:12px 0">
              <div class="receipt-shop-name">☕ WARUNG KUPHI</div>
              <div class="receipt-shop-sub">Struk Pembayaran</div>
              <hr class="receipt-divider">
              <div class="receipt-meta"><span>No. Pesanan</span><span style="font-weight:700;color:#34d399">#${order.seq_today||'?'}</span></div>
              <div class="receipt-meta"><span>Ref</span><span>${order.order_number}</span></div>
              <div class="receipt-meta"><span>Meja</span><span style="color:white">${order.table_number}</span></div>
              <div class="receipt-meta"><span>Kasir</span><span>${order.profiles?.full_name||''}</span></div>
              <div class="receipt-meta"><span>Jam</span><span>${dtTime(order.created_at)}</span></div>
              <hr class="receipt-divider">
              ${items.map(item=>`
                <div class="receipt-item-row">
                  <div style="flex:1">
                    <div class="receipt-item-name">${item.product_name}</div>
                    ${item.notes?`<div class="receipt-item-note">* ${item.notes}</div>`:''}
                  </div>
                  <div style="display:flex;flex-direction:column;align-items:flex-end;gap:1px">
                    <div class="receipt-item-qty">${item.quantity}×${fmt(item.unit_price,false)}</div>
                    <div class="receipt-item-price">${fmt(item.subtotal)}</div>
                  </div>
                </div>
              `).join('')}
              <hr class="receipt-divider">
              <div class="receipt-total-row">
                <div class="receipt-total-label">TOTAL</div>
                <div class="receipt-total-value">${fmt(total)}</div>
              </div>
              ${payMethod==='tunai'&&amountPaid?`
                <div class="receipt-meta"><span>Bayar</span><span style="color:rgba(255,255,255,.8)">${fmt(parseFloat(amountPaid))}</span></div>
                <div class="receipt-meta"><span>Kembalian</span><span style="color:${change>=0?'#34d399':'#f87171'};font-weight:700">${change>=0?fmt(change):'kurang '+fmt(Math.abs(change))}</span></div>
              `:''}
              ${payMethod!=='tunai'?`<div class="receipt-meta"><span>Metode</span><span style="color:#34d399;font-weight:700">${payMethod.toUpperCase()}</span></div>`:''}
              <hr class="receipt-divider">
              <div style="font-size:9px;color:rgba(255,255,255,.25);text-align:center">Terima kasih! Selamat menikmati ☕</div>
            </div>
          </div>
        </div>
      </div>
    `;

    // Bind input
    const inp = document.getElementById('pay-amount');
    if (inp) inp.addEventListener('input', e => {
      amountPaid = e.target.value;
      draw();                      // full re-render updates change + button state
    });

    // Wire window handlers
    window._payMethod = m => { payMethod = m; amountPaid = ''; draw(); };
    window._paySetAmt = amt => { amountPaid = String(amt); draw(); };
  }

  draw();

  window._payConfirm = async () => {
    // If QRIS: show big overlay first, then let user confirm
    if (payMethod === 'qris') {
      showQrisOverlay(total, async () => {
        await doProcessPayment();
      });
      return;
    }
    await doProcessPayment();
  };

  async function doProcessPayment() {
    const btn = document.getElementById('btn-pay');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span style="display:flex;align-items:center;gap:8px;justify-content:center"><span style="width:16px;height:16px;border:2.5px solid rgba(255,255,255,.3);border-top-color:white;border-radius:50%;animation:spin .8s linear infinite;display:inline-block"></span> Memproses...</span>'; }
    try {
      const finalAmt = payMethod === 'tunai' ? parseFloat(amountPaid) : total;
      const r = await api('orders.complete', 'POST', {
        order_id:       order.id,
        payment_method: payMethod,
        amount_paid:    finalAmt,
      });
      showPaymentSuccess(r.order, r.change_amount, window._payBack);
    } catch(e) {
      toast(e.message, 'error');
      if (btn) { btn.disabled = false; btn.textContent = '✅ Konfirmasi Pembayaran — ' + fmt(total); }
    }
  }
}

// ── QRIS Full-screen Overlay ──────────────────────────────────
function showQrisOverlay(total, onConfirm) {
  const ov = document.createElement('div');
  ov.className = 'qris-overlay';
  ov.innerHTML = `
    <div class="qris-overlay-card">
      <div class="qris-overlay-header">
        <div style="font-size:13px;font-weight:700;color:var(--text-3);letter-spacing:.06em;text-transform:uppercase">📱 Pembayaran QRIS</div>
        <button class="qris-close-btn" id="qris-close-btn">✕</button>
      </div>
      <div class="qris-overlay-body">
        <div class="qris-total-badge">${fmt(total)}</div>
        <p style="font-size:13px;color:var(--text-3);margin-bottom:20px;text-align:center">Tunjukkan QR ini ke pelanggan untuk di-scan</p>
        <div class="qris-qr-box">
          <svg width="210" height="210" viewBox="0 0 210 210" xmlns="http://www.w3.org/2000/svg">
            <rect width="210" height="210" fill="white" rx="10"/>
            <rect x="12" y="12" width="66" height="66" rx="5" fill="none" stroke="#0d1f17" stroke-width="5.5"/>
            <rect x="22" y="22" width="46" height="46" rx="3" fill="#0d1f17"/>
            <rect x="132" y="12" width="66" height="66" rx="5" fill="none" stroke="#0d1f17" stroke-width="5.5"/>
            <rect x="142" y="22" width="46" height="46" rx="3" fill="#0d1f17"/>
            <rect x="12" y="132" width="66" height="66" rx="5" fill="none" stroke="#0d1f17" stroke-width="5.5"/>
            <rect x="22" y="142" width="46" height="46" rx="3" fill="#0d1f17"/>
            <g fill="#0d1f17" opacity=".9">
              <rect x="92" y="12" width="9" height="9"/><rect x="105" y="12" width="9" height="9"/><rect x="118" y="12" width="9" height="9"/>
              <rect x="92" y="25" width="9" height="9"/><rect x="118" y="25" width="9" height="9"/>
              <rect x="92" y="38" width="9" height="9"/><rect x="105" y="38" width="9" height="9"/><rect x="118" y="38" width="9" height="9"/>
              <rect x="92" y="51" width="9" height="9"/><rect x="92" y="64" width="9" height="9"/>
              <rect x="12" y="92" width="9" height="9"/><rect x="25" y="92" width="9" height="9"/><rect x="38" y="92" width="9" height="9"/>
              <rect x="51" y="92" width="9" height="9"/><rect x="64" y="92" width="9" height="9"/>
              <rect x="12" y="105" width="9" height="9"/><rect x="38" y="105" width="9" height="9"/><rect x="64" y="105" width="9" height="9"/>
              <rect x="12" y="118" width="9" height="9"/><rect x="25" y="118" width="9" height="9"/><rect x="51" y="118" width="9" height="9"/>
              <rect x="80" y="80" width="9" height="9"/><rect x="92" y="80" width="9" height="9"/><rect x="105" y="80" width="9" height="9"/>
              <rect x="118" y="80" width="9" height="9"/><rect x="130" y="80" width="9" height="9"/>
              <rect x="80" y="92" width="9" height="9"/><rect x="105" y="92" width="9" height="9"/><rect x="130" y="92" width="9" height="9"/>
              <rect x="80" y="105" width="9" height="9"/><rect x="92" y="105" width="9" height="9"/><rect x="118" y="105" width="9" height="9"/>
              <rect x="80" y="118" width="9" height="9"/><rect x="105" y="118" width="9" height="9"/><rect x="130" y="118" width="9" height="9"/>
              <rect x="80" y="130" width="9" height="9"/><rect x="92" y="130" width="9" height="9"/><rect x="118" y="130" width="9" height="9"/>
              <rect x="132" y="92" width="9" height="9"/><rect x="145" y="92" width="9" height="9"/><rect x="158" y="92" width="9" height="9"/>
              <rect x="171" y="92" width="9" height="9"/><rect x="184" y="92" width="9" height="9"/>
              <rect x="132" y="105" width="9" height="9"/><rect x="158" y="105" width="9" height="9"/>
              <rect x="132" y="118" width="9" height="9"/><rect x="145" y="118" width="9" height="9"/><rect x="171" y="118" width="9" height="9"/>
              <rect x="158" y="130" width="9" height="9"/><rect x="184" y="130" width="9" height="9"/>
              <rect x="132" y="145" width="9" height="9"/><rect x="145" y="145" width="9" height="9"/><rect x="171" y="145" width="9" height="9"/>
              <rect x="12" y="132" width="0" height="0"/><rect x="92" y="158" width="9" height="9"/>
              <rect x="105" y="158" width="9" height="9"/><rect x="118" y="158" width="9" height="9"/>
              <rect x="92" y="171" width="9" height="9"/><rect x="92" y="184" width="9" height="9"/>
              <rect x="105" y="184" width="9" height="9"/>
              <rect x="132" y="158" width="9" height="9"/><rect x="158" y="158" width="9" height="9"/>
              <rect x="184" y="158" width="9" height="9"/>
              <rect x="145" y="171" width="9" height="9"/><rect x="171" y="171" width="9" height="9"/>
              <rect x="132" y="184" width="9" height="9"/><rect x="145" y="184" width="9" height="9"/>
              <rect x="158" y="184" width="9" height="9"/><rect x="184" y="184" width="9" height="9"/>
            </g>
            <rect x="92" y="92" width="26" height="26" rx="5" fill="white"/>
            <text x="105" y="109" text-anchor="middle" font-size="16" fill="#059669">☕</text>
          </svg>
          <div class="qris-merchant-name">WARUNG KUPHI</div>
          <div style="font-size:11px;color:#999;margin-top:2px;letter-spacing:.04em">NMID: 123456789012345</div>
        </div>
        <div class="qris-waiting-pill">
          <span class="qris-pulse-dot"></span>Menunggu konfirmasi pembayaran...
        </div>
      </div>
      <div class="qris-overlay-footer">
        <button class="btn btn-secondary" id="qris-back-btn">← Kembali</button>
        <button class="btn btn-primary qris-confirm-btn" id="btn-qris-ok">
          ✅ Pembayaran Diterima
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(ov);
  requestAnimationFrame(() => ov.classList.add('visible'));

  ov.querySelector('#qris-close-btn').addEventListener('click', () => { ov.classList.remove('visible'); setTimeout(() => ov.remove(), 280); });
  ov.querySelector('#qris-back-btn').addEventListener('click', () => { ov.classList.remove('visible'); setTimeout(() => ov.remove(), 280); });
  ov.querySelector('#btn-qris-ok').addEventListener('click', async () => {
    ov.classList.remove('visible'); setTimeout(() => ov.remove(), 280);
    await onConfirm();
  });
}

// ── Payment success overlay ───────────────────────────────────
function showPaymentSuccess(order, changeAmt, onClose) {
  const overlay = document.createElement('div');
  overlay.className = 'payment-success-overlay';
  overlay.innerHTML = `
    <div class="payment-success-icon">✅</div>
    <div class="payment-success-title">Pembayaran Berhasil!</div>
    <div class="payment-success-sub">
      Meja ${order.table_number} · Pesanan #${order.seq_today||''}<br>
      ${dtId(order.completed_at || order.created_at)}
    </div>
    ${order.payment_method==='tunai'&&changeAmt>0?`
      <div class="payment-success-change">
        <div class="payment-success-change-label">Kembalian untuk pelanggan</div>
        <div class="payment-success-change-value">${fmt(changeAmt)}</div>
      </div>
    `:''}
    <div class="payment-success-actions">
      <button class="btn-success-print" id="btn-print-final">🖨️ Cetak Struk</button>
      <button class="btn-success-done"  id="btn-done-success">Selesai →</button>
    </div>
  `;
  document.body.appendChild(overlay);
  window._finishedOrder = order;

  document.getElementById('btn-print-final').addEventListener('click', () => printReceiptData(order));
  document.getElementById('btn-done-success').addEventListener('click', () => {
    overlay.remove();
    onClose();
  });
}

// ── Print final receipt ───────────────────────────────────────
function printReceiptData(order) {
  const items  = order.order_items || [];
  const line   = '─'.repeat(32);
  const ctr    = t => t.padStart(Math.floor((32 + t.length) / 2)).padEnd(32);
  const rows   = [
    ctr('WARUNG KUPHI'), ctr('Struk Pembayaran'), line,
    `No. Pesanan  : #${order.seq_today||'?'}`,
    `Ref          : ${order.order_number}`,
    `Meja         : ${order.table_number||'-'}`,
    `Kasir        : ${order.profiles?.full_name||'-'}`,
    `Waktu        : ${dtId(order.created_at)}`,
    line,
  ];
  items.forEach(i => {
    rows.push(`${(i.product_name||'').substring(0,18).padEnd(18)}${String(i.quantity+'x').padStart(4)}${fmt(i.subtotal).padStart(12)}`);
    if (i.notes) rows.push(`  * ${i.notes}`);
  });
  rows.push(line,
    `${'TOTAL'.padEnd(22)}${fmt(order.total).padStart(10)}`,
    `${'Bayar via'.padEnd(22)}${(order.payment_method||'').toUpperCase().padStart(10)}`);
  if (order.payment_method === 'tunai') {
    rows.push(`${'Dibayar'.padEnd(22)}${fmt(order.amount_paid).padStart(10)}`);
    if (order.change_amount > 0)
      rows.push(`${'Kembalian'.padEnd(22)}${fmt(order.change_amount).padStart(10)}`);
  }
  rows.push(line, ctr('Terima kasih!'), ctr('Selamat menikmati ☕'));
  const w = window.open('', '_blank', 'width=400,height=620');
  w.document.write(`<html><head><title>Struk</title>
    <style>body{font-family:monospace;font-size:12px;padding:16px;white-space:pre}
    @media print{@page{margin:0}body{margin:8px}}</style></head>
    <body onload="print();close()">${rows.join('\n')}</body></html>`);
  w.document.close();
}

// ─────────────────────────────────────────────────────────────
//  HISTORY
// ─────────────────────────────────────────────────────────────
async function renderHistory(pc) {
  const today = dateOnly(new Date().toISOString());
  const week  = dateOnly(new Date(Date.now() - 7 * 86400000).toISOString());
  let dateFrom = week, dateTo = today, search = '', orders = [];

  async function load() {
    const hb = document.getElementById('history-body');
    if (hb) hb.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;
    try {
      const d = await api(`orders.history?date_from=${dateFrom}&date_to=${dateTo}&search=${encodeURIComponent(search)}`);
      orders = d.orders; drawTable();
    } catch(e) { toast(e.message, 'error'); }
  }

  function drawTable() {
    const totalRev = orders.reduce((s, o) => s + Number(o.total), 0);
    const hb = document.getElementById('history-body');
    if (!hb) return;
    hb.innerHTML = `
      <div class="stats-grid" style="margin-bottom:16px">
        ${statCard('💰','Total Revenue',fmt(totalRev),'Periode terpilih','#059669','#ecfdf5','history')}
        ${statCard('📋','Transaksi',orders.length,'Total order selesai','#0284c7','#f0f9ff','history')}
      </div>
      ${orders.length === 0
        ? `<div class="empty-state"><div class="empty-state-icon">📜</div><div class="empty-state-title">Tidak ada transaksi di periode ini</div></div>`
        : `<div class="card" style="overflow-x:auto"><table class="data-table"><thead><tr>
            <th>#</th><th>No. Order</th><th>Meja</th><th>Kasir</th><th>Total</th><th>Metode</th><th>Waktu Selesai</th><th></th>
           </tr></thead><tbody>
           ${orders.map(o => `<tr>
            <td style="color:var(--text-4);font-size:12px">${o.seq_today||'-'}</td>
            <td><span style="font-weight:700;font-size:13px">${o.order_number}</span></td>
            <td>Meja ${o.table_number||'-'}</td>
            <td>${o.profiles?.full_name||o.full_name||'-'}</td>
            <td style="font-weight:700;color:var(--primary)">${fmt(o.total)}</td>
            <td>${o.payment_method==='tunai'?'💵':o.payment_method==='qris'?'📱':'💳'} ${o.payment_method||'-'}</td>
            <td style="color:var(--text-3);font-size:12px">${dtId(o.completed_at||o.created_at)}</td>
            <td><button class="btn btn-ghost btn-sm" onclick="window._hPrint(${o.id})">🖨️ Cetak</button></td>
           </tr>`).join('')}
           </tbody></table></div>`}
    `;
    window._hPrint = id => {
      const o = orders.find(o => o.id == id);
      if (o) printReceiptData(o);
    };
  }

  pc.innerHTML = `
    <div class="page-header">
      <div class="page-title">Riwayat Transaksi</div>
      <div class="page-subtitle">Semua transaksi yang telah selesai</div>
    </div>
    <div class="card card-padded" style="margin-bottom:16px">
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
        <div class="form-group" style="margin:0">
          <label class="form-label">Dari</label>
          <input type="date" class="form-input" style="height:40px" id="h-from" value="${dateFrom}">
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Sampai</label>
          <input type="date" class="form-input" style="height:40px" id="h-to" value="${dateTo}">
        </div>
        <div class="form-group" style="margin:0;flex:1;min-width:140px">
          <label class="form-label">No. Order</label>
          <input class="form-input" style="height:40px" id="h-search" placeholder="WK-..." value="${search}">
        </div>
        <button class="btn btn-primary" style="height:40px" onclick="window._hSearch()">🔍 Cari</button>
      </div>
    </div>
    <div id="history-body"></div>
  `;

  window._hSearch = () => {
    dateFrom = document.getElementById('h-from').value;
    dateTo   = document.getElementById('h-to').value;
    search   = document.getElementById('h-search').value;
    load();
  };
  load();
}

// ─────────────────────────────────────────────────────────────
//  PRODUCTS
// ─────────────────────────────────────────────────────────────
async function renderProducts(pc) {
  pc.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;
  const { products } = await api('products.list');

  let search = '', filterStock = 'all', filterTen = 'all';
  const tenants = [...new Map(products.map(p => [p.tenant_id, p.tenants])).entries()].map(([id, t]) => ({ id, ...t }));

  function draw() {
    const outOfStock = products.filter(p => p.stock == 0);
    const lowStock   = products.filter(p => p.stock > 0 && p.stock <= p.stock_min);

    const filtered = products.filter(p => {
      const mt = filterTen === 'all'   || p.tenant_id == filterTen;
      const ms = !search               || p.name.toLowerCase().includes(search.toLowerCase());
      const mk = filterStock === 'all' ? true
        : filterStock === 'habis'    ? p.stock == 0
        : filterStock === 'menipis'  ? (p.stock > 0 && p.stock <= p.stock_min)
        : p.stock > p.stock_min;
      return mt && ms && mk;
    });

    const grouped = {};
    filtered.forEach(p => {
      if (!grouped[p.tenant_id]) grouped[p.tenant_id] = { tenant: p.tenants, items: [] };
      grouped[p.tenant_id].items.push(p);
    });

    pc.innerHTML = `
      <div class="page-header">
        <div class="page-title">Produk & Stok</div>
        <div class="page-subtitle">Pantau stok semua produk dari semua tenant</div>
      </div>

      ${(outOfStock.length > 0 || lowStock.length > 0) ? `
        <div style="background:linear-gradient(135deg,#7f1d1d,#991b1b);border-radius:var(--radius-lg);padding:12px 18px;margin-bottom:16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
          <span style="font-size:20px">⚠️</span>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700;color:white">Peringatan Stok!</div>
            <div style="font-size:12px;color:#fca5a5;margin-top:2px">
              ${outOfStock.length ? outOfStock.length + ' produk habis' : ''}${outOfStock.length && lowStock.length ? ' · ' : ''}${lowStock.length ? lowStock.length + ' produk menipis' : ''}
            </div>
          </div>
          ${outOfStock.length ? `<button class="btn btn-sm" style="background:rgba(255,255,255,.15);color:white;border:1px solid rgba(255,255,255,.2)"
            onclick="filterStock='habis';draw()">Lihat Habis</button>` : ''}
        </div>
      ` : ''}

      <div style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
        <div style="position:relative;flex:1;min-width:160px">
          <span style="position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:13px">🔍</span>
          <input class="form-input" id="prod-s" style="padding-left:32px;height:40px" placeholder="Cari produk..." value="${search}">
        </div>
        <select class="form-input form-select" id="prod-t" style="width:160px;height:40px">
          <option value="all">Semua Tenant</option>
          ${tenants.map(t => `<option value="${t.id}" ${filterTen==t.id?'selected':''}>${t.name}</option>`).join('')}
        </select>
        <select class="form-input form-select" id="prod-sk" style="width:160px;height:40px">
          <option value="all" ${filterStock==='all'?'selected':''}>Semua Stok</option>
          <option value="habis"   ${filterStock==='habis'?'selected':''}>Stok Habis</option>
          <option value="menipis" ${filterStock==='menipis'?'selected':''}>Stok Menipis</option>
          <option value="aman"    ${filterStock==='aman'?'selected':''}>Stok Aman</option>
        </select>
      </div>

      ${Object.values(grouped).length === 0
        ? `<div class="empty-state"><div class="empty-state-icon">🔍</div><div class="empty-state-title">Tidak ada produk</div></div>`
        : Object.values(grouped).map(({ tenant, items }) => `
          <div class="card" style="margin-bottom:16px">
            <div class="card-header">
              <div style="display:flex;align-items:center;gap:8px">
                <div style="width:7px;height:22px;border-radius:3px;background:${tenant?.color||'var(--primary)'}"></div>
                <div class="card-title">${tenant?.name||''}</div>
                <span style="font-size:12px;color:var(--text-4)">${items.length} produk</span>
              </div>
            </div>
            <div style="overflow-x:auto">
              <table class="data-table"><thead><tr>
                <th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th>
              </tr></thead><tbody>
              ${items.map(p => {
                const pct = Math.min(100, (p.stock / (p.stock_min * 3 || 15)) * 100);
                const [sc, sb, sl] = p.stock == 0
                  ? ['var(--danger)',  'var(--danger-pale)',  'Habis']
                  : p.stock <= p.stock_min
                    ? ['var(--warning)','var(--warning-pale)','Menipis']
                    : ['var(--success)','var(--success-pale)','Tersedia'];
                return `<tr>
                  <td><span style="font-weight:600">${p.category_icon||'🍽️'} ${p.name}</span></td>
                  <td style="font-size:12px;color:var(--text-3)">${p.category_name||'-'}</td>
                  <td style="font-weight:700;color:var(--primary)">${fmt(p.price)}</td>
                  <td>
                    <div style="font-weight:700;font-size:14px;margin-bottom:3px">${p.stock}</div>
                    <div class="stock-bar"><div class="stock-bar-fill" style="width:${pct}%;background:${sc}"></div></div>
                  </td>
                  <td><span class="badge" style="background:${sb};color:${sc}">${sl}</span></td>
                </tr>`;
              }).join('')}
              </tbody></table>
            </div>
          </div>
        `).join('')}
    `;

    document.getElementById('prod-s')?.addEventListener('input', e => { search = e.target.value; draw(); });
    document.getElementById('prod-t')?.addEventListener('change', e => { filterTen = e.target.value; draw(); });
    document.getElementById('prod-sk')?.addEventListener('change', e => { filterStock = e.target.value; draw(); });
  }

  draw();
}

// ─────────────────────────────────────────────────────────────
//  SHIFT
// ─────────────────────────────────────────────────────────────
async function renderShift(pc) {
  pc.innerHTML = `<div class="page-loader"><div class="loading-spinner"></div></div>`;
  const { shifts: history } = await api('shift.history');
  let timer = null;

  function startTimer() {
    if (timer) clearInterval(timer);
    if (!state.activeShift) return;
    timer = setInterval(() => {
      const clk = document.getElementById('shift-clock');
      if (!clk) { clearInterval(timer); return; }
      const ms = Date.now() - new Date(state.activeShift.opened_at);
      const h  = Math.floor(ms / 3600000);
      const m  = Math.floor((ms % 3600000) / 60000);
      const s  = Math.floor((ms % 60000) / 1000);
      clk.innerHTML = `${pad(h)}:${pad(m)}:<span style="font-size:22px;opacity:.6">${pad(s)}</span>`;
    }, 1000);
  }

  function draw() {
    const shift = state.activeShift;
    pc.innerHTML = `
      <div class="page-header">
        <div class="page-title">Manajemen Shift</div>
        <div class="page-subtitle">Kelola waktu kerja dan laporan kas harian</div>
      </div>

      ${shift ? `
        <!-- Active shift card -->
        <div class="shift-card-active" style="margin-bottom:16px">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px">
            <div>
              <div style="font-size:10.5px;color:#6ee7b7;letter-spacing:.1em;font-weight:600;text-transform:uppercase;margin-bottom:8px;display:flex;align-items:center;gap:6px">
                <span style="width:7px;height:7px;border-radius:50%;background:#6ee7b7;animation:pulse-green 2s infinite;display:inline-block"></span>
                Shift Aktif
              </div>
              <div id="shift-clock" style="font-size:40px;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:-.02em">00:00:00</div>
              <div style="font-size:13px;color:#a7f3d0;margin-top:4px">Dibuka: ${dtId(shift.opened_at)}</div>
            </div>
            <div style="text-align:right">
              <div style="font-size:10.5px;color:#6ee7b7;margin-bottom:4px">Total Penjualan</div>
              <div style="font-size:30px;font-weight:800">${fmt(shift.total_sales||0)}</div>
              <div style="font-size:13px;color:#a7f3d0;margin-top:2px">${shift.total_orders||0} order</div>
            </div>
          </div>
          <div style="margin-top:20px">
            <button class="btn btn-lg" style="background:rgba(255,255,255,.15);color:white;border:1px solid rgba(255,255,255,.25);width:100%"
              onclick="document.getElementById('close-panel').style.display=document.getElementById('close-panel').style.display==='none'?'block':'none'">
              🔒 Tutup Shift ↓
            </button>
          </div>
        </div>
        <!-- Close form -->
        <div id="close-panel" style="display:none;margin-bottom:16px">
          <div class="card card-padded">
            <div style="font-size:15px;font-weight:700;margin-bottom:14px">Konfirmasi Tutup Shift</div>
            <div class="form-group">
              <label class="form-label">Uang Aktual di Kasir (Rp)</label>
              <input class="form-input" type="number" id="actual-cash" placeholder="Hitung dan masukkan total uang tunai" style="font-size:16px">
            </div>
            <div class="form-group">
              <label class="form-label">Catatan (opsional)</label>
              <textarea class="form-input" id="close-notes" rows="2" placeholder="Catatan penutupan shift..."></textarea>
            </div>
            <div style="display:flex;gap:10px">
              <button class="btn btn-secondary" onclick="document.getElementById('close-panel').style.display='none'">Batal</button>
              <button class="btn btn-primary" style="flex:1" onclick="window._doCloseShift()">Tutup Shift Sekarang</button>
            </div>
          </div>
        </div>
      ` : `
        <!-- Open shift form -->
        <div class="card card-padded" style="max-width:480px;margin-bottom:16px">
          <div style="text-align:center;padding-bottom:16px;border-bottom:1px solid var(--border-light);margin-bottom:16px">
            <div style="font-size:40px;margin-bottom:8px">⏰</div>
            <div style="font-size:18px;font-weight:700">Shift Belum Dibuka</div>
            <div style="font-size:13px;color:var(--text-3);margin-top:4px">Buka shift untuk mulai menerima order</div>
          </div>
          <div class="form-group">
            <label class="form-label">Modal Awal Kas (Rp)</label>
            <input class="form-input" type="number" id="opening-cash" placeholder="Masukkan modal awal" style="font-size:16px">
          </div>
          <button class="btn btn-primary btn-lg" style="width:100%" onclick="window._doOpenShift()">
            Buka Shift Sekarang →
          </button>
        </div>
      `}

      <!-- History -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📋 Riwayat Shift</div>
        </div>
        ${history.length === 0
          ? `<div class="empty-state"><div class="empty-state-icon">📋</div><div class="empty-state-title">Belum ada riwayat shift</div></div>`
          : `<div style="overflow-x:auto">
            <table class="data-table"><thead><tr>
                <th>Dibuka</th><th>Ditutup</th><th>Total Penjualan</th><th>Modal Awal</th><th>Selisih Kas</th>
              </tr></thead><tbody>
              ${history.map(s => `<tr>
                <td>${dtId(s.opened_at)}</td>
                <td style="font-size:12px;color:var(--text-3)">${s.closed_at ? dtId(s.closed_at) : '-'}</td>
                <td style="font-weight:700;color:var(--primary)">${fmt(s.total_sales)}</td>
                <td>${fmt(s.opening_cash)}</td>
                <td style="font-weight:700;color:${s.cash_difference>=0?'var(--success)':'var(--danger)'}">
                  ${s.cash_difference != null ? (s.cash_difference >= 0 ? '+' : '') + fmt(s.cash_difference) : '-'}
                </td>
              </tr>`).join('')}
              </tbody></table>
            </div>`}
      </div>
    `;

    if (shift) startTimer();

    window._doOpenShift = async () => {
      const cash = Number(document.getElementById('opening-cash')?.value || 0);
      try {
        const { shift } = await api('shift.open', 'POST', { opening_cash: cash });
        state.activeShift = shift; updateShiftUI();
        toast('Shift berhasil dibuka! ✅', 'success');
        renderShift(pc);
      } catch(e) { toast(e.message, 'error'); }
    };

    window._doCloseShift = async () => {
      const cash  = Number(document.getElementById('actual-cash')?.value || 0);
      const notes = document.getElementById('close-notes')?.value || '';
      try {
        await api('shift.close', 'POST', { actual_cash: cash, notes });
        state.activeShift = null; updateShiftUI();
        toast('Shift berhasil ditutup!', 'success');
        clearInterval(timer);
        renderShift(pc);
      } catch(e) { toast(e.message, 'error'); }
    };
  }

  draw();
}

// ─────────────────────────────────────────────────────────────
//  BOOT
// ─────────────────────────────────────────────────────────────
async function boot() {
  try {
    const { shift } = await api('shift.active');
    state.activeShift = shift;
  } catch(e) { /* not logged in or no shift */ }

  renderAppShell();
  updateShiftUI();

  // Keep header shift pill updated every minute
  setInterval(() => {
    if (state.activeShift) updateShiftUI();
  }, 60000);

  // Remove loading screen
  document.getElementById('loading-screen')?.remove();
}

// Hanya jalankan jika user adalah kasir
if (window.WK_USER && window.WK_USER.role === 'kasir') {
  boot();
}