const TENANT = { user: window.WK_USER || {}, menu: 'dashboard', products: [] };
const API_BASE = (window.WK_BASE || '') + '/api/';
const IDR = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Number(n || 0));
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const today = () => new Date().toISOString().slice(0, 10);
const firstDate = () => new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
function hideLoadingScreen() { document.getElementById('loading-screen')?.remove(); }
async function api(action, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json', Accept: 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API_BASE + action, opts);
  let data = {};
  try { data = await res.json(); } catch (_e) { data = { error: 'Respons server tidak valid' }; }
  if (!res.ok) throw new Error(data.error || 'Request gagal');
  return data;
}
function toast(message, isErr = false) {
  const el = document.createElement('div');
  el.textContent = message;
  el.style.cssText = `position:fixed;top:16px;right:16px;z-index:9999;background:${isErr?'#dc2626':'#059669'};color:#fff;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.2)`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}
function modal(content, wide = false) {
  document.getElementById('tenant-modal')?.remove();
  const wrap = document.createElement('div');
  wrap.className = 'modal-overlay';
  wrap.id = 'tenant-modal';
  wrap.innerHTML = `<div class="modal ${wide ? 'modal-lg' : ''}" onclick="event.stopPropagation()">${content}</div>`;
  wrap.onclick = closeModal;
  document.body.appendChild(wrap);
}
function closeModal() { document.getElementById('tenant-modal')?.remove(); }

function sparkline(values = []) {
  if (!values.length || values.every(v => v === 0)) {
    return `<div style="display:flex;align-items:center;justify-content:center;height:100px;color:var(--text-4);font-size:13px;gap:8px"><span style="font-size:20px">📊</span> Belum ada data</div>`;
  }
  const w=560,h=140,pad=18,max=Math.max(...values,1),min=0;
  const pts=values.map((v,i)=>{
    const x=pad+(i/Math.max(values.length-1,1))*(w-pad*2);
    const y=h-pad-((v-min)/(max-min||1))*(h-pad*2);
    return `${x},${y}`;
  });
  const ptsStr=pts.join(' ');
  const areaStr=`${pad},${h-pad} `+ptsStr+` ${pad+(values.length-1)/Math.max(values.length-1,1)*(w-pad*2)},${h-pad}`;
  const gid='tg'+Math.random().toString(36).slice(2,6);
  return `<svg viewBox="0 0 ${w} ${h}" style="width:100%;height:120px;display:block" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#059669" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#059669" stop-opacity="0"/>
    </linearGradient></defs>
    <polygon points="${areaStr}" fill="url(#${gid})"/>
    <polyline points="${ptsStr}" fill="none" stroke="#059669" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    ${pts.map(p=>{const[x,y]=p.split(',');return `<circle cx="${x}" cy="${y}" r="3" fill="#059669" stroke="white" stroke-width="1.5"/>`;}).join('')}
  </svg>`;
}

function sideItem(id, label) { return `<button class="side-text-btn ${TENANT.menu===id?'active':''}" onclick="navigate('${id}')">${label}</button>`; }
function shell() {
  document.getElementById('app-root').innerHTML = `
    <div class="app-layout">
      <aside class="sidebar sidebar-pro">
        <div class="sidebar-brand"><div class="sidebar-logo-icon">🏪</div><div><div class="sidebar-brand-name">Tenant</div><div class="sidebar-brand-sub">${esc(TENANT.user.tenant_name||'')}</div></div></div>
        <nav class="sidebar-menu-text">
          ${sideItem('dashboard','Dashboard')}
          ${sideItem('products','Kelola Menu')}
          ${sideItem('orders','Daftar Pesanan')}
          ${sideItem('report','Laporan Pendapatan')}
        </nav>
        <button class="btn btn-secondary" style="margin:12px" onclick="logout()">Keluar</button>
      </aside>
      <div class="main-content">
        <header class="header"><div class="header-title">Tenant Portal — ${esc(TENANT.user.tenant_name||TENANT.user.full_name||'')}</div></header>
        <div class="page-content" id="tenant-content"></div>
      </div>
    </div>`;
}
const card=(icon,label,value,sub='')=>`
  <div class="stat-card">
    <div class="stat-card-icon">${icon}</div>
    <div class="stat-card-label">${label}</div>
    <div class="stat-card-value">${value}</div>
    ${sub?`<div style="font-size:11px;color:var(--text-4);margin-top:2px">${sub}</div>`:''}
  </div>`;

async function navigate(menu) {
  TENANT.menu=menu; shell();
  const el=document.getElementById('tenant-content');
  el.innerHTML='<div class="page-loader"><div class="loading-spinner"></div></div>';
  try {
    if(menu==='dashboard') await renderDashboard();
    if(menu==='products') await renderProductsWithMode('',false);
    if(menu==='orders') await renderOrders();
    if(menu==='report') await renderReport();
  } catch(e) {
    el.innerHTML=`<div class="empty-state"><div class="empty-state-icon">⚠️</div><div class="empty-state-title">${esc(e.message)}</div></div>`;
  } finally { hideLoadingScreen(); }
}

/* ── DASHBOARD — grafik + chart + data lengkap ── */
async function renderDashboard() {
  const el=document.getElementById('tenant-content');
  try {
    const [d,report]=await Promise.all([
      api('tenant.dashboard'),
      api(`tenant.report?from=${firstDate()}&to=${today()}`)
    ]);
    const rows=report.rows||[];
    const revenues=rows.map(r=>Number(r.revenue||0));
    const orders=rows.map(r=>Number(r.order_count||0));
    const monthRevenue=revenues.reduce((a,b)=>a+b,0);
    const monthOrders=orders.reduce((a,b)=>a+b,0);
    const avgRevDay=rows.length?monthRevenue/rows.length:0;
    const bestDay=rows.length?rows.reduce((a,b)=>Number(b.revenue||0)>Number(a.revenue||0)?b:a,rows[0]):null;

    el.innerHTML=`
      <div class="page-header">
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">Ringkasan performa menu dan pesanan tenant Anda bulan ini.</div>
      </div>

      <div class="stats-grid" style="margin-bottom:20px">
        ${card('💰','Pendapatan Hari Ini',IDR(d.today_income))}
        ${card('🧾','Order Hari Ini',d.today_orders)}
        ${card('📦','Produk Aktif',d.active_products)}
        ${card('📈','Pendapatan Bulan Ini',IDR(monthRevenue))}
        ${card('📊','Order Bulan Ini',monthOrders)}
        ${card('📉','Rata-rata/Hari',IDR(avgRevDay))}
        ${card('⚠️','Stok Menipis',d.low_stock_count||0)}
        ${bestDay?card('🏆','Hari Terbaik',bestDay.sale_date||'-',IDR(bestDay.revenue)):''}
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
        <div class="card card-padded">
          <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:12px">📈 Pendapatan Harian</div>
          ${sparkline(revenues)}
        </div>
        <div class="card card-padded">
          <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:12px">🧾 Jumlah Order Harian</div>
          ${sparkline(orders)}
        </div>
      </div>

      ${d.low_stock_count>0?`
      <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:var(--radius);padding:14px 16px;display:flex;align-items:center;gap:12px">
        <span style="font-size:24px">⚠️</span>
        <div>
          <div style="font-weight:700;color:#92400e">Stok Menipis</div>
          <div style="font-size:13px;color:#78350f">${d.low_stock_count} menu memiliki stok di bawah batas minimum. Segera update stok.</div>
        </div>
        <button class="btn btn-secondary" style="margin-left:auto;white-space:nowrap" onclick="navigate('products')">Lihat Menu</button>
      </div>`:``}`;
  } catch(e) {
    el.innerHTML=`<div class="empty-state"><div class="empty-state-icon">⚠️</div><div class="empty-state-title">${esc(e.message)}</div></div>`;
  }
}

/* ── KELOLA MENU — 1 tombol hapus, klik baris = edit ── */
async function renderProductsWithMode(q='',showDelete=false) {
  const el=document.getElementById('tenant-content');
  const searchQ=(document.getElementById('tp-q')?.value||q||'').trim();
  const d=await api(`tenant.products?search=${encodeURIComponent(searchQ)}`);
  TENANT.products=d.products||[];
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Kelola Menu</div>
      <div class="page-subtitle">${showDelete?'Mode hapus aktif — centang menu yang ingin dihapus.':'Klik baris untuk edit menu.'}</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <input id="tp-q" class="form-input" placeholder="Cari menu..." value="${esc(searchQ)}" style="flex:1;min-width:180px">
      <button class="btn btn-secondary" onclick="renderProductsWithMode(document.getElementById('tp-q').value,${showDelete})">Cari</button>
      <button class="btn btn-primary" onclick="openProductForm()">+ Tambah</button>
      <button class="btn ${showDelete?'btn-danger':'btn-secondary'}"
        onclick="renderProductsWithMode(document.getElementById('tp-q')?.value||'',${!showDelete})">${showDelete?'✕ Batal':'🗑 Hapus'}</button>
      ${showDelete?`<button class="btn btn-danger" id="del-prod-btn" disabled onclick="deleteSelectedProdsNow()">Hapus Terpilih</button>`:''}
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr>
          ${showDelete?'<th style="width:36px"><input type="checkbox" id="sel-all-p" onchange="onSelectAllProds(this)"></th>':''}
          <th>Nama Menu</th><th>Harga</th><th>Stok</th><th>Status</th>
        </tr></thead>
        <tbody>
          ${TENANT.products.length?TENANT.products.map(p=>`
            <tr class="prow" data-id="${p.id}" style="cursor:${showDelete?'default':'pointer'}">
              ${showDelete?`<td onclick="event.stopPropagation()"><input type="checkbox" class="pchk" value="${p.id}" onchange="onProdChkChange()"></td>`:''}
              <td style="font-weight:600">${esc(p.name)}</td>
              <td style="font-weight:600">${IDR(p.price)}</td>
              <td style="color:${p.stock<=(p.stock_min||5)?'var(--danger)':'var(--text-2)'}">${p.stock}${p.stock<=(p.stock_min||5)?' ⚠️':''}</td>
              <td>${Number(p.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}</td>
            </tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-4)">Belum ada menu</td></tr>'}
        </tbody>
      </table>
    </div>`;

  if(!showDelete) {
    document.querySelectorAll('.prow').forEach(row=>row.addEventListener('click',()=>openProductForm(Number(row.dataset.id))));
  }
}

function onSelectAllProds(el) {
  document.querySelectorAll('.pchk').forEach(c=>c.checked=el.checked);
  onProdChkChange();
}
function onProdChkChange() {
  const btn=document.getElementById('del-prod-btn');
  if(btn) btn.disabled=!document.querySelector('.pchk:checked');
}

async function deleteSelectedProdsNow() {
  const ids=Array.from(document.querySelectorAll('.pchk:checked')).map(c=>Number(c.value));
  if(!ids.length) return;
  if(!confirm(`Hapus ${ids.length} menu terpilih?`)) return;
  for(const id of ids) await api('tenant.product.delete','POST',{id}).catch(e=>toast(e.message,true));
  toast('Menu terpilih dihapus');
  renderProductsWithMode('',false);
}

function openProductForm(id=0) {
  const p=TENANT.products.find(x=>Number(x.id)===Number(id));
  modal(`<div class="modal-header"><div class="modal-title">${p?'Edit Menu':'Tambah Menu'}</div><button class="btn btn-ghost btn-sm" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <input type="hidden" id="p-id" value="${p?.id||0}">
      <div class="form-group"><label class="form-label">Nama Menu</label><input id="p-name" class="form-input" value="${esc(p?.name||'')}" placeholder="Nama menu..."></div>
      <div class="form-group"><label class="form-label">Harga</label><input id="p-price" class="form-input" type="number" value="${p?.price||''}" placeholder="0"></div>
      <div class="form-group" style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div><label class="form-label">Stok</label><input id="p-stock" class="form-input" type="number" value="${p?.stock??0}"></div>
        <div><label class="form-label">Min Stok</label><input id="p-min" class="form-input" type="number" value="${p?.stock_min??5}"></div>
      </div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveProduct()">Simpan</button></div>`);
}
async function saveProduct() {
  const payload={
    id:Number(document.getElementById('p-id').value||0),
    name:document.getElementById('p-name').value.trim(),
    price:Number(document.getElementById('p-price').value||0),
    stock:Number(document.getElementById('p-stock').value||0),
    stock_min:Number(document.getElementById('p-min').value||5),
    is_available:1,is_active:1
  };
  if(!payload.name||payload.price<=0) return toast('Nama dan harga harus valid',true);
  await api('tenant.product.save','POST',payload);
  closeModal(); toast('Menu tersimpan'); renderProductsWithMode('',false);
}

/* ── DAFTAR PESANAN — tampilan bersih & responsif ── */
async function renderOrders() {
  const el=document.getElementById('tenant-content');
  const date=document.getElementById('to-date')?.value||today();
  const status=document.getElementById('to-status')?.value||'';
  const d=await api(`tenant.orders?date=${encodeURIComponent(date)}&status=${encodeURIComponent(status)}`);
  const orders=d.orders||[];
  const totalPending=orders.filter(o=>o.status==='pending').length;
  const totalSelesai=orders.filter(o=>o.status==='selesai').length;
  const totalNominal=orders.reduce((a,o)=>a+Number(o.tenant_total||0),0);
  const statusBadge=s=>{
    if(s==='selesai') return '<span class="badge badge-success">Selesai</span>';
    if(s==='diproses') return '<span style="background:#fffbeb;color:#d97706;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600">Diproses</span>';
    return '<span style="background:#f1f5f9;color:#64748b;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600">Pending</span>';
  };
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Daftar Pesanan</div>
      <div class="page-subtitle">Pesanan masuk untuk tenant Anda.</div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
      ${card('🧾','Total Order',orders.length)}
      ${card('⏳','Pending',totalPending)}
      ${card('✅','Selesai',`${totalSelesai}`,IDR(totalNominal))}
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <input id="to-date" class="form-input" type="date" value="${esc(date)}" style="flex:1;min-width:130px">
      <select id="to-status" class="form-input form-select" style="flex:1;min-width:130px">
        <option value="" ${status===''?'selected':''}>Semua Status</option>
        <option value="pending" ${status==='pending'?'selected':''}>Pending</option>
        <option value="diproses" ${status==='diproses'?'selected':''}>Diproses</option>
        <option value="selesai" ${status==='selesai'?'selected':''}>Selesai</option>
      </select>
      <button class="btn btn-secondary" onclick="renderOrders()">Filter</button>
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>No. Order</th><th>Meja</th><th>Status</th><th style="text-align:right">Total Anda</th></tr></thead>
        <tbody>
          ${orders.length?orders.map(o=>`<tr>
            <td style="font-weight:600;font-family:monospace;font-size:13px">${esc(o.order_number)}</td>
            <td><span style="background:var(--surface2);padding:2px 8px;border-radius:6px;font-size:12px">Meja ${o.table_number||'-'}</span></td>
            <td>${statusBadge(o.status)}</td>
            <td style="text-align:right;font-weight:700;color:var(--success)">${IDR(o.tenant_total)}</td>
          </tr>`).join(''):'<tr><td colspan="4" style="text-align:center;padding:48px;color:var(--text-4)">Tidak ada pesanan pada tanggal ini</td></tr>'}
        </tbody>
        ${orders.length?`<tfoot><tr style="background:var(--surface2)">
          <td colspan="3" style="font-weight:700;padding:10px 16px">Total Pendapatan</td>
          <td style="text-align:right;font-weight:700;color:var(--success);padding:10px 16px">${IDR(totalNominal)}</td>
        </tr></tfoot>`:''}
      </table>
    </div>`;
}

/* ── LAPORAN PENDAPATAN — chart + ringkasan + tabel ── */
async function renderReport() {
  const el=document.getElementById('tenant-content');
  const from=document.getElementById('tr-from')?.value||firstDate();
  const to=document.getElementById('tr-to')?.value||today();
  const d=await api(`tenant.report?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
  const rows=d.rows||[];
  const totalRev=rows.reduce((a,r)=>a+Number(r.revenue||0),0);
  const totalOrd=rows.reduce((a,r)=>a+Number(r.order_count||0),0);
  const avgPerDay=rows.length?totalRev/rows.length:0;
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Laporan Pendapatan</div>
      <div class="page-subtitle">Analisis pendapatan harian tenant Anda.</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <input id="tr-from" class="form-input" type="date" value="${esc(from)}" style="flex:1;min-width:130px">
      <span style="color:var(--text-3);font-size:13px">s/d</span>
      <input id="tr-to" class="form-input" type="date" value="${esc(to)}" style="flex:1;min-width:130px">
      <button class="btn btn-secondary" onclick="renderReport()">Terapkan</button>
      <a class="btn btn-primary" href="${API_BASE}tenant.report.csv?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}" style="text-decoration:none">⬇ Export CSV</a>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
      ${card('💰','Total Pendapatan',IDR(totalRev))}
      ${card('🧾','Total Order',totalOrd)}
      ${card('📊','Rata-rata/Hari',IDR(avgPerDay))}
    </div>
    <div class="card card-padded" style="margin-bottom:16px">
      <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:12px">📈 Tren Pendapatan Harian</div>
      ${sparkline(rows.map(r=>Number(r.revenue||0)))}
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Tanggal</th><th style="text-align:center">Jumlah Order</th><th style="text-align:right">Pendapatan</th></tr></thead>
        <tbody>
          ${rows.length?rows.map(r=>`<tr>
            <td style="font-weight:600">${r.sale_date}</td>
            <td style="text-align:center">${r.order_count||0}</td>
            <td style="text-align:right;font-weight:700;color:var(--success)">${IDR(r.revenue)}</td>
          </tr>`).join(''):'<tr><td colspan="3" style="text-align:center;padding:40px;color:var(--text-4)">Tidak ada data pada rentang ini</td></tr>'}
        </tbody>
        ${rows.length?`<tfoot><tr style="background:var(--surface2)">
          <td style="font-weight:700;padding:10px 16px">Total (${rows.length} hari)</td>
          <td style="text-align:center;font-weight:700;padding:10px 16px">${totalOrd}</td>
          <td style="text-align:right;font-weight:700;color:var(--success);padding:10px 16px">${IDR(totalRev)}</td>
        </tr></tfoot>`:''}
      </table>
    </div>`;
}

function logout() { window.location.href=(window.WK_BASE||'')+'/logout'; }
if(TENANT.user.role==='tenant') { shell(); navigate('dashboard'); }
