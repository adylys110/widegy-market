const ADMIN = { user: window.WK_USER || {}, menu: 'dashboard', tenants: [], products: [], users: [] };
const API_BASE = (window.WK_BASE || '') + '/api/';
const IDR = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Number(n || 0));
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const today = () => new Date().toISOString().slice(0, 10);
const firstDate = () => new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
function hideLoadingScreen() { document.getElementById('loading-screen')?.remove(); }
async function api(action, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json', Accept: 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API_BASE + action, opts);
  let data = {};
  try { data = await res.json(); } catch (_e) { data = { error: 'Respons server tidak valid' }; }
  if (!res.ok) throw new Error(data.error || 'Request gagal');
  return data;
}
function toast(message, isErr = false) {
  const el = document.createElement('div');
  el.textContent = message;
  el.style.cssText = `position:fixed;top:16px;right:16px;z-index:9999;background:${isErr?'#dc2626':'#059669'};color:#fff;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.2)`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}
function modal(content, wide = false) {
  closeModal();
  const wrap = document.createElement('div');
  wrap.className = 'modal-overlay';
  wrap.id = 'generic-modal';
  wrap.innerHTML = `<div class="modal ${wide ? 'modal-lg' : ''}" onclick="event.stopPropagation()">${content}</div>`;
  wrap.onclick = closeModal;
  document.body.appendChild(wrap);
}
function closeModal() { document.getElementById('generic-modal')?.remove(); }

function sparkline(values = []) {
  if (!values.length || values.every(v => v === 0)) {
    return `<div style="display:flex;align-items:center;justify-content:center;height:120px;color:var(--text-4);font-size:13px;gap:8px"><span style="font-size:20px">📊</span> Belum ada data grafik</div>`;
  }
  const w=600,h=160,pad=20,max=Math.max(...values,1),min=0;
  const pts = values.map((v,i)=>{
    const x=pad+(i/Math.max(values.length-1,1))*(w-pad*2);
    const y=h-pad-((v-min)/(max-min||1))*(h-pad*2);
    return `${x},${y}`;
  });
  const ptsStr=pts.join(' ');
  const areaStr=`${pad},${h-pad} `+ptsStr+` ${pad+(values.length-1)/Math.max(values.length-1,1)*(w-pad*2)},${h-pad}`;
  const gid='sg'+Math.random().toString(36).slice(2,6);
  return `<svg viewBox="0 0 ${w} ${h}" style="width:100%;height:140px;display:block" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#059669" stop-opacity="0.18"/>
      <stop offset="100%" stop-color="#059669" stop-opacity="0"/>
    </linearGradient></defs>
    <polygon points="${areaStr}" fill="url(#${gid})"/>
    <polyline points="${ptsStr}" fill="none" stroke="#059669" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    ${pts.map(p=>{const[x,y]=p.split(',');return `<circle cx="${x}" cy="${y}" r="3.5" fill="#059669" stroke="white" stroke-width="1.5"/>`;}).join('')}
  </svg>`;
}

function barChart(labels=[],values=[]) {
  if(!labels.length) return `<div style="display:flex;align-items:center;justify-content:center;height:100px;color:var(--text-4);font-size:13px">Belum ada data</div>`;
  const max=Math.max(...values,1);
  return `<div style="display:flex;align-items:flex-end;gap:8px;padding:8px 0;overflow-x:auto;height:120px">`+
    labels.map((l,i)=>{
      const pct=(values[i]/max)*80;
      return `<div style="display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;min-width:40px">
        <div style="font-size:10px;color:var(--text-3);text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:60px">${IDR(values[i])}</div>
        <div style="width:28px;height:80px;background:var(--surface3);border-radius:4px;overflow:hidden;display:flex;align-items:flex-end">
          <div style="width:100%;height:${pct}px;background:#059669;border-radius:4px 4px 0 0;min-height:3px"></div>
        </div>
        <div style="font-size:10px;color:var(--text-3);text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:60px">${esc(l)}</div>
      </div>`;
    }).join('')+`</div>`;
}

function sideItem(id, label) { return `<button class="side-text-btn ${ADMIN.menu===id?'active':''}" onclick="navigate('${id}')">${label}</button>`; }
function shell() {
  document.getElementById('app-root').innerHTML = `
    <div class="app-layout">
      <aside class="sidebar sidebar-pro">
        <div class="sidebar-brand">
          <div class="sidebar-logo-icon">🛡️</div>
          <div><div class="sidebar-brand-name">Admin</div><div class="sidebar-brand-sub">Warung Kuphi</div></div>
        </div>
        <nav class="sidebar-menu-text">
          ${sideItem('dashboard','Dashboard')}
          ${sideItem('tenants','Kelola Data Tenant')}
          ${sideItem('products','Kelola Menu')}
          ${sideItem('orders','Data Pesanan')}
          ${sideItem('reports','Laporan Penjualan')}
          ${sideItem('sharing','Pembagian Hasil')}
          ${sideItem('users','Manajemen Pengguna')}
        </nav>
        <button class="btn btn-secondary" style="margin:12px" onclick="logout()">Keluar</button>
      </aside>
      <div class="main-content">
        <header class="header"><div class="header-title">Admin Portal — ${esc(ADMIN.user.full_name||'')}</div></header>
        <div class="page-content page-enter" id="admin-content"></div>
      </div>
    </div>`;
}
async function navigate(menu) {
  ADMIN.menu=menu; shell();
  const el=document.getElementById('admin-content');
  el.innerHTML='<div class="page-loader"><div class="loading-spinner"></div></div>';
  try {
    if(menu==='dashboard') await renderDashboard();
    if(menu==='tenants') await renderTenants();
    if(menu==='products') await renderProducts();
    if(menu==='orders') await renderOrders();
    if(menu==='reports') await renderSalesReport();
    if(menu==='sharing') await renderSharing();
    if(menu==='users') await renderUsersWithMode('',false);
  } catch(e) {
    el.innerHTML=`<div class="empty-state"><div class="empty-state-icon">⚠️</div><div class="empty-state-title">${esc(e.message)}</div></div>`;
  } finally { hideLoadingScreen(); }
}
const card=(icon,label,value,sub='')=>`
  <div class="stat-card">
    <div class="stat-card-icon">${icon}</div>
    <div class="stat-card-label">${label}</div>
    <div class="stat-card-value">${value}</div>
    ${sub?`<div style="font-size:11px;color:var(--text-4);margin-top:2px">${sub}</div>`:''}
  </div>`;

async function renderDashboard() {
  const el=document.getElementById('admin-content');
  try {
    const [dash,salesMonth,ordersToday,usersData,tenantsData]=await Promise.all([
      api('admin.dashboard'),
      api(`admin.report.sales?from=${firstDate()}&to=${today()}`),
      api(`admin.orders?date=${today()}`),
      api('admin.users'),
      api('admin.tenants'),
    ]);
    const rows=salesMonth.rows||[];
    const monthSales=rows.reduce((a,b)=>a+Number(b.total_sales||0),0);
    const monthOrders=rows.reduce((a,b)=>a+Number(b.total_orders||0),0);
    const activeCashier=(usersData.users||[]).filter(u=>u.role==='kasir'&&Number(u.is_active)===1).length;
    const activeOrder=(ordersToday.orders||[]).filter(o=>o.status!=='selesai').length;
    const chartVals=rows.map(r=>Number(r.total_sales||0));
    const tenants=tenantsData.tenants||[];
    const topTenants=[...tenants].sort((a,b)=>Number(b.sales_today||0)-Number(a.sales_today||0)).slice(0,6);
    el.innerHTML=`
      <div class="page-header">
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">Pantau performa operasional harian dan bulanan secara real-time.</div>
      </div>
      <div class="stats-grid" style="margin-bottom:20px">
        ${card('💰','Penjualan Hari Ini',IDR(dash.today_sales))}
        ${card('📅','Penjualan Bulan Ini',IDR(monthSales))}
        ${card('🧾','Order Hari Ini',dash.today_orders)}
        ${card('🗓️','Order Bulan Ini',monthOrders)}
        ${card('🏪','Tenant Aktif',dash.active_tenants)}
        ${card('👨‍💼','Kasir Aktif',activeCashier)}
        ${card('⚡','Order Aktif',activeOrder)}
        ${card('👥','User Aktif',dash.active_users)}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
        <div class="card card-padded">
          <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:12px">📈 Grafik Penjualan Bulan Ini</div>
          ${sparkline(chartVals)}
        </div>
        <div class="card card-padded">
          <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:8px">🏆 Top Tenant Hari Ini</div>
          ${barChart(topTenants.map(t=>t.name),topTenants.map(t=>Number(t.sales_today||0)))}
        </div>
      </div>
      <div class="card" style="overflow-x:auto">
        <div style="padding:16px 20px 8px;font-weight:700;font-size:14px;color:var(--text-1);border-bottom:1px solid var(--border)">Ringkasan Semua Tenant</div>
        <table class="data-table">
          <thead><tr><th>Tenant</th><th>Produk Aktif</th><th>Sales Hari Ini</th><th>Status</th></tr></thead>
          <tbody>
            ${tenants.slice(0,10).map(t=>`<tr>
              <td style="font-weight:600">${esc(t.name)}</td>
              <td>${t.products_count}</td>
              <td style="font-weight:600;color:var(--success)">${IDR(t.sales_today)}</td>
              <td>${Number(t.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  } catch(e) {
    el.innerHTML=`<div class="empty-state"><div class="empty-state-icon">⚠️</div><div class="empty-state-title">${esc(e.message)}</div></div>`;
  }
}

function renderTenantDetail(tenantId) {
  api(`admin.tenant.detail?id=${tenantId}`).then(d=>{
    const t=d.tenant;
    const vals=(d.sales_rows||[]).map(r=>Number(r.revenue||0));
    modal(`
      <div class="modal-header">
        <div class="modal-title" style="display:flex;align-items:center;gap:8px">
          <span style="width:8px;height:8px;border-radius:50%;background:${Number(t.is_active)?'#059669':'#94a3b8'};display:inline-block"></span>
          ${esc(t.name)}
        </div>
        <button class="btn btn-ghost btn-sm" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body">
        <div class="stats-grid" style="margin-bottom:16px">
          ${card('📦','Produk Aktif',t.active_products)}
          ${card('👥','User Aktif',t.active_users)}
          ${card('💵','Sales Hari Ini',IDR(t.sales_today))}
          ${card('📈','Sales Bulan Ini',IDR(t.sales_month))}
        </div>
        <div class="card card-padded">
          <div style="font-weight:700;font-size:13px;color:var(--text-2);margin-bottom:10px">Grafik Penjualan</div>
          ${sparkline(vals)}
        </div>
      </div>`,true);
  }).catch(e=>toast(e.message,true));
}

async function renderTenants() {
  const el=document.getElementById('admin-content');
  const q=(document.getElementById('tenant-search')?.value||'').trim();
  const d=await api(`admin.tenants?search=${encodeURIComponent(q)}`);
  ADMIN.tenants=d.tenants||[];
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Kelola Data Tenant</div>
      <div class="page-subtitle">Klik kartu tenant untuk melihat detail dan grafik penjualan.</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <input id="tenant-search" class="form-input" placeholder="Cari nama tenant..." value="${esc(q)}" style="flex:1;min-width:200px">
      <button class="btn btn-secondary" onclick="renderTenants()">Cari</button>
      <button class="btn btn-primary" onclick="openTenantForm()">+ Tambah Tenant</button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px">
      ${ADMIN.tenants.length?ADMIN.tenants.map(t=>`
        <div onclick="renderTenantDetail(${t.id})" style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:16px;cursor:pointer;transition:all .18s;box-shadow:var(--shadow-sm)"
          onmouseover="this.style.borderColor='#059669';this.style.boxShadow='0 4px 16px rgba(5,150,105,.12)'"
          onmouseout="this.style.borderColor='var(--border)';this.style.boxShadow='var(--shadow-sm)'">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <div style="font-weight:700;font-size:14px;color:var(--text-1)">${esc(t.name)}</div>
            ${Number(t.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
            <div style="background:var(--surface2);border-radius:8px;padding:8px 10px">
              <div style="font-size:11px;color:var(--text-4)">Produk Aktif</div>
              <div style="font-size:18px;font-weight:700;color:var(--text-1)">${t.products_count}</div>
            </div>
            <div style="background:var(--surface2);border-radius:8px;padding:8px 10px">
              <div style="font-size:11px;color:var(--text-4)">Sales Hari Ini</div>
              <div style="font-size:13px;font-weight:700;color:var(--success)">${IDR(t.sales_today)}</div>
            </div>
          </div>
          <div style="font-size:11px;color:var(--text-4);display:flex;align-items:center;gap:4px">👆 Klik untuk detail lengkap</div>
        </div>
      `).join(''):`<div style="grid-column:1/-1;text-align:center;padding:48px;color:var(--text-4)">Tenant tidak ditemukan</div>`}
    </div>`;
}

function openTenantForm() {
  modal(`<div class="modal-header"><div class="modal-title">Tambah Tenant</div><button class="btn btn-ghost btn-sm" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Nama Tenant</label><input id="t-name" class="form-input" placeholder="Nama tenant..."></div>
      <div class="form-group"><label class="form-label">Deskripsi</label><textarea id="t-desc" class="form-input" style="min-height:80px" placeholder="Deskripsi singkat..."></textarea></div>
      <div class="form-group"><label class="form-label">Warna Brand</label><input id="t-color" class="form-input" value="#059669" type="color" style="height:40px;padding:4px"></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveTenant()">Simpan</button></div>`);
}
async function saveTenant() {
  const name=document.getElementById('t-name').value.trim();
  if(!name) return toast('Nama tenant wajib diisi',true);
  await api('admin.tenant.save','POST',{name,description:document.getElementById('t-desc').value.trim(),color:document.getElementById('t-color').value||'#059669',is_active:1});
  closeModal(); toast('Tenant tersimpan'); renderTenants();
}

async function renderProducts() {
  const el=document.getElementById('admin-content');
  const q=(document.getElementById('prod-search')?.value||'').trim();
  const tenantId=document.getElementById('prod-tenant-filter')?.value||'';
  const [pd,td]=await Promise.all([
    api(`admin.products?search=${encodeURIComponent(q)}&tenant_id=${encodeURIComponent(tenantId)}`),
    api('admin.tenants')
  ]);
  ADMIN.products=pd.products||[];ADMIN.tenants=td.tenants||[];
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Kelola Menu</div>
      <div class="page-subtitle">Klik baris menu untuk melihat informasi detail dan status stok.</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <input id="prod-search" class="form-input" placeholder="Cari nama menu..." value="${esc(q)}" style="flex:1;min-width:160px">
      <select id="prod-tenant-filter" class="form-input form-select" style="flex:1;min-width:140px">
        <option value="">Semua Tenant</option>
        ${ADMIN.tenants.map(t=>`<option value="${t.id}" ${String(tenantId)===String(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}
      </select>
      <button class="btn btn-secondary" onclick="renderProducts()">Filter</button>
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Nama Menu</th><th>Tenant</th><th>Harga</th><th>Stok</th><th>Status</th></tr></thead>
        <tbody>
          ${ADMIN.products.length?ADMIN.products.map(p=>`
            <tr style="cursor:pointer" onclick="openProductDetail(${p.id})"
              onmouseover="this.style.background='var(--surface2)'" onmouseout="this.style.background=''">
              <td style="font-weight:600">${esc(p.name)}</td>
              <td><span style="background:var(--surface2);padding:2px 8px;border-radius:20px;font-size:12px">${esc(p.tenant_name)}</span></td>
              <td style="font-weight:600">${IDR(p.price)}</td>
              <td style="color:${p.stock<=(p.stock_min||5)?'var(--danger)':'var(--text-2)'}">${p.stock}${p.stock<=(p.stock_min||5)?' ⚠️':''}</td>
              <td>${Number(p.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}</td>
            </tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-4)">Tidak ada menu ditemukan</td></tr>'}
        </tbody>
      </table>
    </div>`;
}

function openProductDetail(id) {
  const p=ADMIN.products.find(x=>Number(x.id)===Number(id));
  if(!p) return;
  modal(`
    <div class="modal-header">
      <div class="modal-title">${esc(p.name)}</div>
      <button class="btn btn-ghost btn-sm" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="stats-grid" style="margin-bottom:16px">
        ${card('🏪','Tenant',esc(p.tenant_name))}
        ${card('💵','Harga',IDR(p.price))}
        ${card('📦','Stok Saat Ini',p.stock)}
        ${card('⚠️','Minimum Stok',p.stock_min||5)}
      </div>
      <div style="background:var(--surface2);border-radius:var(--radius);padding:12px 14px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:13px;color:var(--text-2)">Status Menu</span>
        ${Number(p.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}
      </div>
      <div style="background:var(--surface2);border-radius:var(--radius);padding:12px 14px;display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:13px;color:var(--text-2)">Ketersediaan</span>
        ${Number(p.is_available)?'<span class="badge badge-success">Tersedia</span>':'<span class="badge badge-default">Tidak Tersedia</span>'}
      </div>
      ${p.stock<=(p.stock_min||5)?`<div style="margin-top:12px;background:#fef2f2;border:1px solid #fecaca;border-radius:var(--radius);padding:10px 14px;font-size:13px;color:#dc2626;font-weight:600">⚠️ Stok menipis — segera hubungi tenant untuk restock</div>`:''}
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Tutup</button>
      <button class="btn btn-danger" onclick="deleteProductAdmin(${p.id})">Hapus Menu</button>
    </div>`);
}

async function deleteProductAdmin(id) {
  if(!confirm('Hapus menu ini?')) return;
  await api('admin.product.delete','POST',{id}); closeModal(); toast('Menu dihapus'); renderProducts();
}

async function renderOrders() {
  const el=document.getElementById('admin-content');
  const date=document.getElementById('ord-date')?.value||today();
  const status=document.getElementById('ord-status')?.value||'';
  const search=(document.getElementById('ord-search')?.value||'').trim();
  const d=await api(`admin.orders?date=${encodeURIComponent(date)}&status=${encodeURIComponent(status)}&search=${encodeURIComponent(search)}`);
  const orders=d.orders||[];
  const totalPending=orders.filter(o=>o.status==='pending').length;
  const totalSelesai=orders.filter(o=>o.status==='selesai').length;
  const totalNominal=orders.reduce((a,o)=>a+Number(o.total||0),0);
  const statusBadge=s=>{
    if(s==='selesai') return '<span class="badge badge-success">Selesai</span>';
    if(s==='diproses') return '<span style="background:#fffbeb;color:#d97706;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600">Diproses</span>';
    return '<span style="background:#f1f5f9;color:#64748b;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600">Pending</span>';
  };
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Data Pesanan</div>
      <div class="page-subtitle">Pantau semua transaksi dan status pesanan.</div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
      ${card('🧾','Total Order',orders.length)}
      ${card('⏳','Pending',totalPending)}
      ${card('✅','Selesai',`${totalSelesai}`,IDR(totalNominal))}
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <input id="ord-date" class="form-input" type="date" value="${esc(date)}" style="flex:1;min-width:130px">
      <select id="ord-status" class="form-input form-select" style="flex:1;min-width:130px">
        <option value="" ${status===''?'selected':''}>Semua Status</option>
        <option value="pending" ${status==='pending'?'selected':''}>Pending</option>
        <option value="diproses" ${status==='diproses'?'selected':''}>Diproses</option>
        <option value="selesai" ${status==='selesai'?'selected':''}>Selesai</option>
      </select>
      <input id="ord-search" class="form-input" placeholder="Nomor order..." value="${esc(search)}" style="flex:2;min-width:150px">
      <button class="btn btn-secondary" onclick="renderOrders()">Filter</button>
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>No. Order</th><th>Meja</th><th>Kasir</th><th>Status</th><th style="text-align:right">Total</th></tr></thead>
        <tbody>
          ${orders.length?orders.map(o=>`<tr>
            <td style="font-weight:600;font-family:monospace;font-size:13px">${esc(o.order_number)}</td>
            <td><span style="background:var(--surface2);padding:2px 8px;border-radius:6px;font-size:12px">Meja ${o.table_number||'-'}</span></td>
            <td style="color:var(--text-2)">${esc(o.kasir_name)}</td>
            <td>${statusBadge(o.status)}</td>
            <td style="text-align:right;font-weight:700;color:var(--success)">${IDR(o.total)}</td>
          </tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:48px;color:var(--text-4)">Tidak ada pesanan pada tanggal ini</td></tr>'}
        </tbody>
        ${orders.length?`<tfoot><tr style="background:var(--surface2)">
          <td colspan="4" style="font-weight:700;padding:10px 16px">Total</td>
          <td style="text-align:right;font-weight:700;color:var(--success);padding:10px 16px">${IDR(totalNominal)}</td>
        </tr></tfoot>`:''}
      </table>
    </div>`;
}

async function renderSalesReport() {
  const el=document.getElementById('admin-content');
  const from=document.getElementById('sales-from')?.value||firstDate();
  const to=document.getElementById('sales-to')?.value||today();
  const d=await api(`admin.report.sales?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
  const rows=d.rows||[];
  const totalSales=rows.reduce((a,r)=>a+Number(r.total_sales||0),0);
  const totalOrders=rows.reduce((a,r)=>a+Number(r.total_orders||0),0);
  const avgPerDay=rows.length?totalSales/rows.length:0;
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Laporan Penjualan</div>
      <div class="page-subtitle">Analisis tren penjualan harian dalam rentang waktu yang dipilih.</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <input id="sales-from" class="form-input" type="date" value="${esc(from)}" style="flex:1;min-width:130px">
      <span style="color:var(--text-3);font-size:13px">s/d</span>
      <input id="sales-to" class="form-input" type="date" value="${esc(to)}" style="flex:1;min-width:130px">
      <button class="btn btn-secondary" onclick="renderSalesReport()">Terapkan</button>
      <a class="btn btn-primary" href="${API_BASE}admin.report.sales.csv?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}" style="text-decoration:none">⬇ Export CSV</a>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
      ${card('💰','Total Penjualan',IDR(totalSales))}
      ${card('🧾','Total Order',totalOrders)}
      ${card('📊','Rata-rata/Hari',IDR(avgPerDay))}
    </div>
    <div class="card card-padded" style="margin-bottom:16px">
      <div style="font-weight:700;font-size:14px;color:var(--text-1);margin-bottom:12px">📈 Tren Penjualan Harian</div>
      ${sparkline(rows.map(r=>Number(r.total_sales||0)))}
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Tanggal</th><th style="text-align:center">Jumlah Order</th><th style="text-align:right">Total Penjualan</th></tr></thead>
        <tbody>
          ${rows.length?rows.map(r=>`<tr>
            <td style="font-weight:600">${r.sale_date}</td>
            <td style="text-align:center">${r.total_orders}</td>
            <td style="text-align:right;font-weight:700;color:var(--success)">${IDR(r.total_sales)}</td>
          </tr>`).join(''):'<tr><td colspan="3" style="text-align:center;padding:40px;color:var(--text-4)">Tidak ada data pada rentang ini</td></tr>'}
        </tbody>
        ${rows.length?`<tfoot><tr style="background:var(--surface2)">
          <td style="font-weight:700;padding:10px 16px">Total (${rows.length} hari)</td>
          <td style="text-align:center;font-weight:700;padding:10px 16px">${totalOrders}</td>
          <td style="text-align:right;font-weight:700;color:var(--success);padding:10px 16px">${IDR(totalSales)}</td>
        </tr></tfoot>`:''}
      </table>
    </div>`;
}

async function renderSharing() {
  const el=document.getElementById('admin-content');
  const from=document.getElementById('share-from')?.value||firstDate();
  const to=document.getElementById('share-to')?.value||today();
  const pct=Number(document.getElementById('share-pct')?.value||20);
  const d=await api(`admin.report.share?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&share_percent=${encodeURIComponent(pct)}`);
  const rows=d.rows||[];
  const totalGross=rows.reduce((a,r)=>a+Number(r.gross_sales||0),0);
  const totalFee=rows.reduce((a,r)=>a+Number(r.platform_fee||0),0);
  const totalNet=rows.reduce((a,r)=>a+Number(r.tenant_net||0),0);
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Pembagian Hasil Tenant</div>
      <div class="page-subtitle">Kalkulasi pembagian pendapatan antara platform dan tenant.</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <input id="share-from" class="form-input" type="date" value="${esc(from)}" style="flex:1;min-width:130px">
      <span style="color:var(--text-3);font-size:13px">s/d</span>
      <input id="share-to" class="form-input" type="date" value="${esc(to)}" style="flex:1;min-width:130px">
      <div style="display:flex;align-items:center;gap:6px">
        <label style="font-size:13px;color:var(--text-2);white-space:nowrap">Fee:</label>
        <input id="share-pct" class="form-input" type="number" min="1" max="100" value="${pct}" style="width:70px">
        <span style="font-size:13px;color:var(--text-2)">%</span>
      </div>
      <button class="btn btn-secondary" onclick="renderSharing()">Hitung</button>
      <a class="btn btn-primary" href="${API_BASE}admin.report.share.csv?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&share_percent=${encodeURIComponent(pct)}" style="text-decoration:none">⬇ Export CSV</a>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
      ${card('💰','Total Omzet',IDR(totalGross))}
      ${card('🏦','Fee Platform',IDR(totalFee))}
      ${card('💚','Net Tenant',IDR(totalNet))}
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Tenant</th><th style="text-align:right">Omzet</th><th style="text-align:right">Fee Platform</th><th style="text-align:right">Pendapatan Tenant</th></tr></thead>
        <tbody>
          ${rows.map(r=>`<tr>
            <td style="font-weight:600">${esc(r.name)}</td>
            <td style="text-align:right">${IDR(r.gross_sales)}</td>
            <td style="text-align:right;color:var(--danger)">${IDR(r.platform_fee)}</td>
            <td style="text-align:right;font-weight:700;color:var(--success)">${IDR(r.tenant_net)}</td>
          </tr>`).join('')}
        </tbody>
        ${rows.length?`<tfoot><tr style="background:var(--surface2)">
          <td style="font-weight:700;padding:10px 16px">Total</td>
          <td style="text-align:right;font-weight:700;padding:10px 16px">${IDR(totalGross)}</td>
          <td style="text-align:right;font-weight:700;color:var(--danger);padding:10px 16px">${IDR(totalFee)}</td>
          <td style="text-align:right;font-weight:700;color:var(--success);padding:10px 16px">${IDR(totalNet)}</td>
        </tr></tfoot>`:''}
      </table>
    </div>`;
}

async function renderUsersWithMode(q='',showDelete=false) {
  const el=document.getElementById('admin-content');
  const [ud,td]=await Promise.all([api(`admin.users?search=${encodeURIComponent(q)}`),api('admin.tenants')]);
  ADMIN.users=ud.users||[];ADMIN.tenants=td.tenants||[];
  el.innerHTML=`
    <div class="page-header">
      <div class="page-title">Manajemen Pengguna</div>
      <div class="page-subtitle">${showDelete?'Mode hapus aktif — centang pengguna yang ingin dihapus, lalu klik Hapus Terpilih.':'Klik baris untuk edit pengguna.'}</div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <input id="usr-q" class="form-input" placeholder="Cari username / nama..." value="${esc(q)}" style="flex:1;min-width:180px">
      <button class="btn btn-secondary" onclick="renderUsersWithMode(document.getElementById('usr-q').value,${showDelete})">Cari</button>
      <button class="btn btn-primary" onclick="openUserForm()">+ Tambah User</button>
      <button class="btn ${showDelete?'btn-danger':'btn-secondary'}"
        onclick="renderUsersWithMode(document.getElementById('usr-q')?.value||'',${!showDelete})">${showDelete?'✕ Batal':'🗑 Hapus'}</button>
      ${showDelete?`<button class="btn btn-danger" id="confirm-del-btn" disabled onclick="deleteSelectedUsersNow()">Hapus Terpilih</button>`:''}
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="data-table">
        <thead><tr>
          ${showDelete?'<th style="width:36px"><input type="checkbox" id="sel-all-u" onchange="onSelectAllUsers(this)"></th>':''}
          <th>Username</th><th>Nama Lengkap</th><th>Role</th><th>Tenant</th><th>Status</th>
        </tr></thead>
        <tbody>
          ${ADMIN.users.map(u=>`<tr class="urow" data-id="${u.id}" style="cursor:${showDelete?'default':'pointer'}">
            ${showDelete?`<td onclick="event.stopPropagation()"><input type="checkbox" class="uchk" value="${u.id}" onchange="onUserChkChange()"></td>`:''}
            <td style="font-weight:600;font-family:monospace;font-size:13px">${esc(u.username)}</td>
            <td>${esc(u.full_name)}</td>
            <td><span style="background:var(--surface2);padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600;text-transform:capitalize">${esc(u.role)}</span></td>
            <td style="color:var(--text-3)">${esc(u.tenant_name||'—')}</td>
            <td>${Number(u.is_active)?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-default">Nonaktif</span>'}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  if(!showDelete) {
    document.querySelectorAll('.urow').forEach(row=>row.addEventListener('click',()=>openUserForm(Number(row.dataset.id))));
  }
}

function onSelectAllUsers(el) {
  document.querySelectorAll('.uchk').forEach(c=>c.checked=el.checked);
  onUserChkChange();
}
function onUserChkChange() {
  const btn=document.getElementById('confirm-del-btn');
  if(btn) btn.disabled=!document.querySelector('.uchk:checked');
}

async function deleteSelectedUsersNow() {
  const ids=Array.from(document.querySelectorAll('.uchk:checked')).map(c=>Number(c.value));
  if(!ids.length) return;
  if(!confirm(`Hapus ${ids.length} pengguna terpilih?`)) return;
  for(const id of ids) await api('admin.user.delete','POST',{id}).catch(e=>toast(e.message,true));
  toast('Pengguna terpilih dihapus');
  renderUsersWithMode('',false);
}

function openUserForm(id=0) {
  const u=ADMIN.users.find(x=>Number(x.id)===Number(id));
  modal(`<div class="modal-header"><div class="modal-title">${u?'Edit Pengguna':'Tambah Pengguna'}</div><button class="btn btn-ghost btn-sm" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <input type="hidden" id="u-id" value="${u?.id||0}">
      <div class="form-group"><label class="form-label">Username</label><input id="u-username" class="form-input" value="${esc(u?.username||'')}" placeholder="username..."></div>
      <div class="form-group"><label class="form-label">Nama Lengkap</label><input id="u-name" class="form-input" value="${esc(u?.full_name||'')}" placeholder="Nama lengkap..."></div>
      <div class="form-group"><label class="form-label">Role</label><select id="u-role" class="form-input form-select" onchange="toggleTenantSelect()">
        <option value="kasir" ${u?.role==='kasir'?'selected':''}>Kasir</option>
        <option value="tenant" ${u?.role==='tenant'?'selected':''}>Tenant</option>
        <option value="admin" ${u?.role==='admin'?'selected':''}>Admin</option>
      </select></div>
      <div class="form-group"><label class="form-label">Tenant</label><select id="u-tenant" class="form-input form-select">
        ${ADMIN.tenants.map(t=>`<option value="${t.id}" ${Number(u?.tenant_id)===Number(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}
      </select></div>
      <div class="form-group"><label class="form-label">Password ${u?'<span style="color:var(--text-4);font-weight:400">(kosongkan jika tidak diubah)</span>':''}</label><input id="u-pass" class="form-input" type="password" placeholder="${u?'(opsional)':'min. 6 karakter'}"></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveUser()">Simpan</button></div>`);
  toggleTenantSelect();
}
function toggleTenantSelect() { const role=document.getElementById('u-role')?.value; const t=document.getElementById('u-tenant'); if(t) t.disabled=role!=='tenant'; }
async function saveUser() {
  const payload={
    id:Number(document.getElementById('u-id').value||0),
    username:document.getElementById('u-username').value.trim(),
    full_name:document.getElementById('u-name').value.trim(),
    role:document.getElementById('u-role').value,
    tenant_id:document.getElementById('u-role').value==='tenant'?Number(document.getElementById('u-tenant').value):null,
    password:document.getElementById('u-pass').value.trim(),
    is_active:1
  };
  if(!payload.username||!payload.full_name) return toast('Username dan nama wajib diisi',true);
  if(!payload.id&&payload.password.length<6) return toast('Password minimal 6 karakter',true);
  await api('admin.user.save','POST',payload);
  closeModal(); toast('Pengguna tersimpan'); renderUsersWithMode('',false);
}

function logout() { window.location.href=(window.WK_BASE||'')+'/logout'; }
if(ADMIN.user.role==='admin') { shell(); navigate('dashboard'); }
