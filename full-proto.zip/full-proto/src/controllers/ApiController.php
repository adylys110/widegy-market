<?php
// ============================================================
// src/controllers/ApiController.php  — revised
// ============================================================

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../middleware/auth.php';

class ApiController {
    private array $user;
    public function __construct() { $this->user = requireAuth(); }

    public function handle(string $action): void {
        header('Content-Type: application/json; charset=utf-8');
        try {
            match ($action) {
                'me'                 => $this->me(),
                'shift.active'       => $this->shiftActive(),
                'shift.open'         => $this->shiftOpen(),
                'shift.close'        => $this->shiftClose(),
                'shift.history'      => $this->shiftHistory(),
                'products.list'      => $this->productsList(),
                'products.stock'     => $this->productsStock(),
                'tables.list'        => $this->tablesList(),
                'orders.create'      => $this->ordersCreate(),
                'orders.complete'    => $this->ordersComplete(),
                'orders.active'      => $this->ordersActive(),
                'orders.history'     => $this->ordersHistory(),
                'orders.item.status' => $this->ordersItemStatus(),
                'orders.selesai'     => $this->ordersSelesai(),
                'dashboard.stats'    => $this->dashboardStats(),
                'admin.dashboard'    => $this->adminDashboard(),
                'admin.tenants'      => $this->adminTenants(),
                'admin.tenant.save'  => $this->adminTenantSave(),
                'admin.products'     => $this->adminProducts(),
                'admin.product.save' => $this->adminProductSave(),
                'admin.product.delete' => $this->adminProductDelete(),
                'admin.orders'       => $this->adminOrders(),
                'admin.users'        => $this->adminUsers(),
                'admin.user.save'    => $this->adminUserSave(),
                'admin.user.delete'  => $this->adminUserDelete(),
                'admin.tenant.detail'=> $this->adminTenantDetail(),
                'admin.report.sales' => $this->adminReportSales(),
                'admin.report.share' => $this->adminReportShare(),
                'admin.report.sales.csv' => $this->adminReportSalesCsv(),
                'admin.report.share.csv' => $this->adminReportShareCsv(),
                'tenant.dashboard'   => $this->tenantDashboard(),
                'tenant.products'    => $this->tenantProducts(),
                'tenant.product.save'=> $this->tenantProductSave(),
                'tenant.product.delete'=> $this->tenantProductDelete(),
                'tenant.orders'      => $this->tenantOrders(),
                'tenant.report'      => $this->tenantReport(),
                'tenant.report.csv'  => $this->tenantReportCsv(),
                default              => jsonResponse(['error' => 'Unknown action'], 404),
            };
        } catch (Throwable $e) {
            jsonResponse(['error' => $e->getMessage()], 500);
        }
    }

    private function me(): void { jsonResponse(['user' => $this->user]); }

    // ── Shift ──────────────────────────────────────────────
    private function shiftActive(): void {
        $s = db()->prepare('SELECT * FROM shifts WHERE kasir_id=? AND status="aktif" ORDER BY opened_at DESC LIMIT 1');
        $s->execute([$this->user['id']]);
        jsonResponse(['shift' => $s->fetch() ?: null]);
    }
    private function shiftOpen(): void {
        $this->requirePost();
        $b = $this->jsonBody();
        $s = db()->prepare('SELECT id FROM shifts WHERE kasir_id=? AND status="aktif" LIMIT 1');
        $s->execute([$this->user['id']]);
        if ($s->fetch()) jsonResponse(['error'=>'Shift sudah aktif'],400);
        $s = db()->prepare('INSERT INTO shifts (kasir_id,opening_cash,status) VALUES (?,?,"aktif")');
        $s->execute([$this->user['id'],(float)($b['opening_cash']??0)]);
        $id = db()->lastInsertId();
        $s = db()->prepare('SELECT * FROM shifts WHERE id=?');
        $s->execute([$id]);
        jsonResponse(['shift' => $s->fetch()]);
    }
    private function shiftClose(): void {
        $this->requirePost();
        $b = $this->jsonBody();
        $s = db()->prepare('SELECT * FROM shifts WHERE kasir_id=? AND status="aktif" LIMIT 1');
        $s->execute([$this->user['id']]);
        $shift = $s->fetch();
        if (!$shift) jsonResponse(['error'=>'Tidak ada shift aktif'],400);
        $diff = (float)($b['actual_cash']??0) - $shift['total_sales'];
        db()->prepare('UPDATE shifts SET status="tutup",closed_at=NOW(),actual_cash=?,cash_difference=?,notes=? WHERE id=?')
            ->execute([(float)($b['actual_cash']??0),$diff,trim($b['notes']??''),$shift['id']]);
        $s = db()->prepare('SELECT * FROM shifts WHERE id=?');
        $s->execute([$shift['id']]);
        jsonResponse(['shift' => $s->fetch()]);
    }
    private function shiftHistory(): void {
        $s = db()->prepare('SELECT s.*,u.full_name FROM shifts s JOIN users u ON s.kasir_id=u.id WHERE s.kasir_id=? AND s.status="tutup" ORDER BY s.opened_at DESC LIMIT 10');
        $s->execute([$this->user['id']]);
        jsonResponse(['shifts' => $s->fetchAll()]);
    }

    // ── Products ───────────────────────────────────────────
    private function productsList(): void {
        $s = db()->query('SELECT p.*,t.name AS tenant_name,t.color AS tenant_color,c.name AS category_name,c.icon AS category_icon FROM products p JOIN tenants t ON p.tenant_id=t.id LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 AND t.is_active=1 ORDER BY t.id,p.name');
        $products = $s->fetchAll();
        foreach ($products as &$p) {
            $p['tenants']    = ['id'=>$p['tenant_id'],'name'=>$p['tenant_name'],'color'=>$p['tenant_color']];
            $p['categories'] = ['id'=>$p['category_id'],'name'=>$p['category_name'],'icon'=>$p['category_icon']];
        }
        jsonResponse(['products' => $products]);
    }
    private function productsStock(): void {
        $s = db()->query('SELECT p.*,t.name AS tenant_name FROM products p JOIN tenants t ON p.tenant_id=t.id WHERE p.is_active=1 AND (p.stock=0 OR p.stock<=p.stock_min) ORDER BY p.stock ASC');
        $alerts = $s->fetchAll();
        foreach ($alerts as &$a) $a['tenants']=['name'=>$a['tenant_name']];
        jsonResponse(['alerts' => $alerts]);
    }

    // ── Tables ─────────────────────────────────────────────
    private function tablesList(): void {
        jsonResponse(['tables' => db()->query('SELECT * FROM restaurant_tables ORDER BY number')->fetchAll()]);
    }

    // ── Orders ─────────────────────────────────────────────

    /** Create order — pending, NO payment yet */
    private function ordersCreate(): void {
        $this->requirePost();
        $b = $this->jsonBody();
        $cartItems   = $b['cart_items'] ?? [];
        $tableId     = (int)($b['table_id'] ?? 0);
        $tableNumber = (int)($b['table_number'] ?? 0);
        if (empty($cartItems)) jsonResponse(['error'=>'Keranjang kosong'],400);
        if (!$tableId)         jsonResponse(['error'=>'Pilih meja terlebih dahulu'],400);

        $s = db()->prepare('SELECT id FROM shifts WHERE kasir_id=? AND status="aktif" LIMIT 1');
        $s->execute([$this->user['id']]);
        $shift = $s->fetch();
        if (!$shift) jsonResponse(['error'=>'Buka shift terlebih dahulu'],400);

        $subtotal = array_sum(array_map(fn($i)=>(float)$i['price']*(int)$i['quantity'], $cartItems));

        // Sequential number for today
        $seqS = db()->prepare('SELECT COUNT(*)+1 FROM orders WHERE DATE(created_at)=CURDATE()');
        $seqS->execute();
        $seqToday = (int)$seqS->fetchColumn();

        $orderNumber = generateOrderNumber();
        db()->beginTransaction();
        try {
            $s = db()->prepare('INSERT INTO orders (order_number,kasir_id,shift_id,table_id,table_number,subtotal,total,amount_paid,change_amount,status) VALUES (?,?,?,?,?,?,?,0,0,"pending")');
            $s->execute([$orderNumber,$this->user['id'],$shift['id'],$tableId,$tableNumber,$subtotal,$subtotal]);
            $orderId = db()->lastInsertId();

            foreach ($cartItems as $item) {
                $qty     = (int)$item['quantity'];
                $price   = (float)$item['price'];
                $itemNote = trim($item['notes'] ?? '');
                db()->prepare('INSERT INTO order_items (order_id,product_id,tenant_id,product_name,quantity,unit_price,subtotal,notes) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([$orderId,$item['id'],$item['tenant_id'],$item['name'],$qty,$price,$price*$qty,$itemNote]);
                db()->prepare('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?')
                    ->execute([$qty,$item['id'],$qty]);
            }

            db()->prepare('UPDATE restaurant_tables SET is_occupied=1 WHERE id=?')->execute([$tableId]);
            db()->prepare('UPDATE shifts SET total_orders=total_orders+1 WHERE id=?')->execute([$shift['id']]);
            db()->commit();
            jsonResponse(['success'=>true,'order_number'=>$orderNumber,'order_id'=>$orderId,'seq_today'=>$seqToday]);
        } catch (Throwable $e) {
            db()->rollBack();
            jsonResponse(['error'=>$e->getMessage()],500);
        }
    }

    /** Selesaikan pesanan + bayar */
    private function ordersComplete(): void {
        $this->requirePost();
        $b             = $this->jsonBody();
        $orderId       = (int)($b['order_id'] ?? 0);
        $paymentMethod = $b['payment_method'] ?? 'tunai';
        $amountPaid    = (float)($b['amount_paid'] ?? 0);
        if (!$orderId) jsonResponse(['error'=>'Order ID tidak valid'],400);

        $s = db()->prepare('SELECT * FROM orders WHERE id=? AND status IN ("pending","diproses")');
        $s->execute([$orderId]);
        $order = $s->fetch();
        if (!$order) jsonResponse(['error'=>'Order tidak ditemukan'],404);

        if ($paymentMethod==='tunai' && $amountPaid < $order['total'])
            jsonResponse(['error'=>'Jumlah bayar kurang'],400);
        if ($paymentMethod!=='tunai') $amountPaid = $order['total'];
        $changeAmt = max(0, $amountPaid - $order['total']);

        db()->beginTransaction();
        try {
            db()->prepare('UPDATE orders SET status="selesai",payment_method=?,amount_paid=?,change_amount=?,completed_at=NOW() WHERE id=?')
                ->execute([$paymentMethod,$amountPaid,$changeAmt,$orderId]);
            db()->prepare('UPDATE order_items SET status="selesai",completed_at=NOW() WHERE order_id=?')
                ->execute([$orderId]);
            db()->prepare('UPDATE restaurant_tables SET is_occupied=0 WHERE id=?')
                ->execute([$order['table_id']]);
            db()->prepare('UPDATE shifts SET total_sales=total_sales+? WHERE id=?')
                ->execute([$order['total'],$order['shift_id']]);
            db()->commit();

            // Build full receipt data
            $s = db()->prepare('SELECT o.*,u.full_name FROM orders o JOIN users u ON o.kasir_id=u.id WHERE o.id=?');
            $s->execute([$orderId]);
            $fullOrder = $s->fetch();
            $fullOrder['profiles'] = ['full_name'=>$fullOrder['full_name']];
            $iS = db()->prepare('SELECT oi.*,t.name AS tn,t.color AS tc FROM order_items oi LEFT JOIN tenants t ON oi.tenant_id=t.id WHERE oi.order_id=?');
            $iS->execute([$orderId]);
            $items = $iS->fetchAll();
            foreach ($items as &$it) $it['tenants']=['name'=>$it['tn'],'color'=>$it['tc']];
            $fullOrder['order_items'] = $items;
            $fullOrder['change_amount'] = $changeAmt;

            jsonResponse(['success'=>true,'order'=>$fullOrder,'change_amount'=>$changeAmt]);
        } catch (Throwable $e) {
            db()->rollBack();
            jsonResponse(['error'=>$e->getMessage()],500);
        }
    }

    private function ordersActive(): void {
        $s = db()->query(
            'SELECT o.*,u.full_name,
                (SELECT COUNT(*) FROM orders o2 WHERE DATE(o2.created_at)=DATE(o.created_at) AND o2.id<=o.id) AS seq_today,
                GROUP_CONCAT(
                    JSON_OBJECT(
                        "id",oi.id,"order_id",oi.order_id,"product_id",oi.product_id,"tenant_id",oi.tenant_id,
                        "product_name",oi.product_name,"quantity",oi.quantity,"unit_price",oi.unit_price,
                        "subtotal",oi.subtotal,"status",oi.status,"notes",oi.notes,
                        "tenant_name",t.name,"tenant_color",t.color
                    ) SEPARATOR "|||"
                ) AS items_raw
             FROM orders o
             JOIN users u ON o.kasir_id=u.id
             LEFT JOIN order_items oi ON oi.order_id=o.id
             LEFT JOIN tenants t ON oi.tenant_id=t.id
             WHERE o.status IN ("pending","diproses")
             GROUP BY o.id ORDER BY o.created_at ASC'
        );
        jsonResponse(['orders' => $this->parseOrdersWithItems($s->fetchAll())]);
    }

    private function ordersSelesai(): void {
        $today = date('Y-m-d');
        $s = db()->prepare(
            'SELECT o.*,u.full_name,
                (SELECT COUNT(*) FROM orders o2 WHERE DATE(o2.created_at)=DATE(o.created_at) AND o2.id<=o.id) AS seq_today,
                GROUP_CONCAT(
                    JSON_OBJECT(
                        "id",oi.id,"product_name",oi.product_name,"quantity",oi.quantity,
                        "subtotal",oi.subtotal,"status",oi.status,"notes",oi.notes,"tenant_id",oi.tenant_id,
                        "tenant_name",t.name,"tenant_color",t.color
                    ) SEPARATOR "|||"
                ) AS items_raw
             FROM orders o JOIN users u ON o.kasir_id=u.id
             LEFT JOIN order_items oi ON oi.order_id=o.id
             LEFT JOIN tenants t ON oi.tenant_id=t.id
             WHERE o.status="selesai" AND DATE(o.created_at)=?
             GROUP BY o.id ORDER BY o.completed_at DESC LIMIT 30'
        );
        $s->execute([$today]);
        jsonResponse(['orders' => $this->parseOrdersWithItems($s->fetchAll())]);
    }

    private function ordersHistory(): void {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
        $dateTo   = $_GET['date_to']   ?? date('Y-m-d');
        $search   = $_GET['search']    ?? '';
        $sql    = 'SELECT o.*,u.full_name FROM orders o JOIN users u ON o.kasir_id=u.id WHERE o.status="selesai" AND o.created_at>=? AND o.created_at<=?';
        $params = [$dateFrom.' 00:00:00', $dateTo.' 23:59:59'];
        if ($search) { $sql.=' AND o.order_number LIKE ?'; $params[]="%$search%"; }
        $sql .= ' ORDER BY o.created_at DESC LIMIT 200';
        $s = db()->prepare($sql);
        $s->execute($params);
        $orders = $s->fetchAll();
        foreach ($orders as &$order) {
            $iS = db()->prepare('SELECT oi.*,t.name AS tn,t.color AS tc FROM order_items oi LEFT JOIN tenants t ON oi.tenant_id=t.id WHERE oi.order_id=?');
            $iS->execute([$order['id']]);
            $items = $iS->fetchAll();
            foreach ($items as &$it) $it['tenants']=['name'=>$it['tn'],'color'=>$it['tc']];
            $order['order_items'] = $items;
            $order['profiles']    = ['full_name'=>$order['full_name']];
        }
        jsonResponse(['orders' => $orders]);
    }

    private function ordersItemStatus(): void {
        $this->requirePost();
        $b = $this->jsonBody();
        $itemId = (int)($b['item_id']??0);
        $status = $b['status']??'';
        if (!in_array($status,['pending','diproses','selesai'])) jsonResponse(['error'=>'Status tidak valid'],400);
        db()->prepare('UPDATE order_items SET status=?,completed_at=? WHERE id=?')
            ->execute([$status,$status==='selesai'?date('Y-m-d H:i:s'):null,$itemId]);
        jsonResponse(['success'=>true]);
    }

    private function dashboardStats(): void {
        $today = date('Y-m-d');
        $s = db()->prepare('SELECT COALESCE(SUM(total),0) AS sales,COUNT(*) AS count FROM orders WHERE status="selesai" AND DATE(created_at)=?');
        $s->execute([$today]);
        $sales = $s->fetch();
        $activeCount = db()->query('SELECT COUNT(*) FROM orders WHERE status IN ("pending","diproses")')->fetchColumn();
        $s = db()->query('SELECT p.*,t.name AS tenant_name FROM products p JOIN tenants t ON p.tenant_id=t.id WHERE p.is_active=1 AND (p.stock=0 OR p.stock<=p.stock_min) ORDER BY p.stock ASC');
        $stockAlerts = $s->fetchAll();
        foreach ($stockAlerts as &$a) $a['tenants']=['name'=>$a['tenant_name']];
        $s = db()->query('SELECT o.*,u.full_name FROM orders o JOIN users u ON o.kasir_id=u.id ORDER BY o.created_at DESC LIMIT 10');
        $recentOrders = $s->fetchAll();
        foreach ($recentOrders as &$ro) $ro['profiles']=['full_name'=>$ro['full_name']];
        jsonResponse(['today_sales'=>(float)$sales['sales'],'active_orders'=>(int)$activeCount,'stock_alerts'=>$stockAlerts,'recent_orders'=>$recentOrders]);
    }

    private function requirePost(): void {
        if ($_SERVER['REQUEST_METHOD']!=='POST') jsonResponse(['error'=>'Method not allowed'],405);
    }
    private function sanitizeLike(string $value): string {
        return '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($value)) . '%';
    }
    private function isDuplicateKeyError(Throwable $e): bool {
        return $e instanceof PDOException && (($e->errorInfo[1] ?? 0) == 1062);
    }
    private function outputCsv(string $filename, array $headers, array $rows): void {
        header_remove('Content-Type');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $fp = fopen('php://output', 'w');
        fputcsv($fp, $headers);
        foreach ($rows as $row) {
            fputcsv($fp, $row);
        }
        fclose($fp);
        exit;
    }
    private function requireRole(array $roles): void {
        if (!in_array($this->user['role'] ?? '', $roles, true)) {
            jsonResponse(['error' => 'Forbidden'], 403);
        }
    }
    private function tenantScopeId(): int {
        $tenantId = (int)($this->user['tenant_id'] ?? 0);
        if ($tenantId <= 0) {
            jsonResponse(['error' => 'Akun tenant belum terhubung ke data tenant'], 400);
        }
        return $tenantId;
    }
    private function jsonBody(): array {
        return json_decode(file_get_contents('php://input'),true)??[];
    }
    private function parseOrdersWithItems(array $rows): array {
        $orders = [];
        foreach ($rows as $row) {
            $items = [];
            if (!empty($row['items_raw'])) {
                foreach (explode('|||',$row['items_raw']) as $j) {
                    $item = json_decode($j,true);
                    if ($item) {
                        $item['tenants']=['id'=>$item['tenant_id']??null,'name'=>$item['tenant_name']??'','color'=>$item['tenant_color']??'#059669'];
                        $items[] = $item;
                    }
                }
            }
            $row['order_items'] = $items;
            $row['profiles']    = ['full_name'=>$row['full_name']];
            unset($row['items_raw'],$row['full_name']);
            $orders[] = $row;
        }
        return $orders;
    }

    // ── Admin ──────────────────────────────────────────────
    private function adminDashboard(): void {
        $this->requireRole(['admin']);
        $today = date('Y-m-d');
        $sales = db()->prepare('SELECT COALESCE(SUM(total),0) FROM orders WHERE status="selesai" AND DATE(created_at)=?');
        $sales->execute([$today]);
        $orders = db()->prepare('SELECT COUNT(*) FROM orders WHERE DATE(created_at)=?');
        $orders->execute([$today]);
        $tenants = db()->query('SELECT COUNT(*) FROM tenants WHERE is_active=1')->fetchColumn();
        $users = db()->query('SELECT COUNT(*) FROM users WHERE is_active=1')->fetchColumn();
        jsonResponse([
            'today_sales' => (float)$sales->fetchColumn(),
            'today_orders' => (int)$orders->fetchColumn(),
            'active_tenants' => (int)$tenants,
            'active_users' => (int)$users,
        ]);
    }
    private function adminTenants(): void {
        $this->requireRole(['admin']);
        $search = trim($_GET['search'] ?? '');
        $sql = 'SELECT t.*,
                   (SELECT COUNT(*) FROM products p WHERE p.tenant_id=t.id AND p.is_active=1) AS products_count,
                   (SELECT COALESCE(SUM(oi.subtotal),0)
                    FROM order_items oi
                    JOIN orders o ON o.id=oi.order_id
                    WHERE oi.tenant_id=t.id AND o.status="selesai" AND DATE(o.created_at)=CURDATE()) AS sales_today
                FROM tenants t';
        $params = [];
        if ($search !== '') {
            $sql .= ' WHERE t.name LIKE ?';
            $params[] = $this->sanitizeLike($search);
        }
        $sql .= ' ORDER BY t.id DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        jsonResponse(['tenants' => $stmt->fetchAll()]);
    }
    private function adminTenantSave(): void {
        $this->requireRole(['admin']);
        $this->requirePost();
        $b = $this->jsonBody();
        $id = (int)($b['id'] ?? 0);
        $name = trim($b['name'] ?? '');
        if ($name === '') jsonResponse(['error' => 'Nama tenant wajib diisi'], 400);
        $description = trim($b['description'] ?? '');
        $color = trim($b['color'] ?? '#059669');
        $isActive = (int)($b['is_active'] ?? 1) ? 1 : 0;
        try {
            if ($id > 0) {
                db()->prepare('UPDATE tenants SET name=?,description=?,color=?,is_active=? WHERE id=?')
                    ->execute([$name,$description,$color,$isActive,$id]);
            } else {
                db()->prepare('INSERT INTO tenants (name,description,color,is_active) VALUES (?,?,?,?)')
                    ->execute([$name,$description,$color,$isActive]);
            }
        } catch (Throwable $e) {
            if ($this->isDuplicateKeyError($e)) {
                jsonResponse(['error' => 'Nama tenant sudah digunakan'], 400);
            }
            throw $e;
        }
        $this->adminTenants();
    }
    private function adminTenantDetail(): void {
        $this->requireRole(['admin']);
        $tenantId = (int)($_GET['id'] ?? 0);
        if ($tenantId <= 0) jsonResponse(['error' => 'Tenant tidak valid'], 400);
        $stmt = db()->prepare('SELECT t.*,
                  (SELECT COUNT(*) FROM products p WHERE p.tenant_id=t.id) AS total_products,
                  (SELECT COUNT(*) FROM products p WHERE p.tenant_id=t.id AND p.is_active=1) AS active_products,
                  (SELECT COUNT(*) FROM users u WHERE u.tenant_id=t.id) AS total_users,
                  (SELECT COUNT(*) FROM users u WHERE u.tenant_id=t.id AND u.is_active=1) AS active_users,
                  (SELECT COALESCE(SUM(oi.subtotal),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.tenant_id=t.id AND o.status="selesai" AND DATE(o.created_at)=CURDATE()) AS sales_today,
                  (SELECT COALESCE(SUM(oi.subtotal),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.tenant_id=t.id AND o.status="selesai" AND DATE(o.created_at)>=DATE_FORMAT(CURDATE(),"%Y-%m-01")) AS sales_month
                FROM tenants t WHERE t.id=? LIMIT 1');
        $stmt->execute([$tenantId]);
        $tenant = $stmt->fetch();
        if (!$tenant) jsonResponse(['error' => 'Tenant tidak ditemukan'], 404);
        $salesRowsStmt = db()->prepare('SELECT DATE(o.created_at) AS sale_date, COALESCE(SUM(oi.subtotal),0) AS revenue
                FROM orders o
                JOIN order_items oi ON oi.order_id=o.id
                WHERE oi.tenant_id=? AND o.status="selesai" AND DATE(o.created_at) >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
                GROUP BY DATE(o.created_at)
                ORDER BY sale_date ASC');
        $salesRowsStmt->execute([$tenantId]);
        jsonResponse(['tenant' => $tenant, 'sales_rows' => $salesRowsStmt->fetchAll()]);
    }
    private function adminProducts(): void {
        $this->requireRole(['admin']);
        $search = trim($_GET['search'] ?? '');
        $tenantId = (int)($_GET['tenant_id'] ?? 0);
        $sql = 'SELECT p.*, t.name AS tenant_name, t.color AS tenant_color, c.name AS category_name
                FROM products p
                JOIN tenants t ON t.id = p.tenant_id
                LEFT JOIN categories c ON c.id = p.category_id
                WHERE 1=1';
        $params = [];
        if ($tenantId > 0) {
            $sql .= ' AND p.tenant_id=?';
            $params[] = $tenantId;
        }
        if ($search !== '') {
            $sql .= ' AND p.name LIKE ?';
            $params[] = $this->sanitizeLike($search);
        }
        $sql .= ' ORDER BY p.id DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        jsonResponse(['products' => $stmt->fetchAll()]);
    }
    private function adminProductSave(): void {
        $this->requireRole(['admin']);
        $this->requirePost();
        $b = $this->jsonBody();
        $id = (int)($b['id'] ?? 0);
        $tenantId = (int)($b['tenant_id'] ?? 0);
        $name = trim($b['name'] ?? '');
        $price = (float)($b['price'] ?? 0);
        $stock = (int)($b['stock'] ?? 0);
        $stockMin = (int)($b['stock_min'] ?? 5);
        if ($tenantId <= 0 || $name === '' || $price <= 0) jsonResponse(['error' => 'Data produk belum valid'], 400);
        if ($stock < 0 || $stockMin < 0) jsonResponse(['error' => 'Stok tidak valid'], 400);
        try {
            if ($id > 0) {
                db()->prepare('UPDATE products SET tenant_id=?,name=?,price=?,stock=?,stock_min=?,is_available=?,is_active=? WHERE id=?')
                    ->execute([$tenantId,$name,$price,$stock,$stockMin,(int)($b['is_available'] ?? 1),(int)($b['is_active'] ?? 1),$id]);
            } else {
                db()->prepare('INSERT INTO products (tenant_id,name,price,stock,stock_min,is_available,is_active) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$tenantId,$name,$price,$stock,$stockMin,(int)($b['is_available'] ?? 1),(int)($b['is_active'] ?? 1)]);
            }
        } catch (Throwable $e) {
            if ($this->isDuplicateKeyError($e)) {
                jsonResponse(['error' => 'Produk dengan nama ini sudah ada'], 400);
            }
            throw $e;
        }
        $this->adminProducts();
    }
    private function adminProductDelete(): void {
        $this->requireRole(['admin']);
        $this->requirePost();
        $id = (int)(($this->jsonBody())['id'] ?? 0);
        if ($id <= 0) jsonResponse(['error' => 'Produk tidak valid'], 400);
        db()->prepare('UPDATE products SET is_active=0,is_available=0 WHERE id=?')->execute([$id]);
        jsonResponse(['success' => true]);
    }
    private function adminOrders(): void {
        $this->requireRole(['admin']);
        $today = $_GET['date'] ?? date('Y-m-d');
        $status = trim($_GET['status'] ?? '');
        $search = trim($_GET['search'] ?? '');
        $sql = 'SELECT o.id,o.order_number,o.table_number,o.status,o.total,o.payment_method,o.created_at,o.completed_at,
                       u.full_name AS kasir_name
                FROM orders o
                JOIN users u ON u.id=o.kasir_id
                WHERE DATE(o.created_at)=?';
        $params = [$today];
        if ($status !== '') {
            $sql .= ' AND o.status=?';
            $params[] = $status;
        }
        if ($search !== '') {
            $sql .= ' AND o.order_number LIKE ?';
            $params[] = $this->sanitizeLike($search);
        }
        $sql .= ' ORDER BY o.id DESC LIMIT 200';
        $s = db()->prepare($sql);
        $s->execute($params);
        jsonResponse(['orders' => $s->fetchAll()]);
    }
    private function adminUsers(): void {
        $this->requireRole(['admin']);
        $search = trim($_GET['search'] ?? '');
        $sql = 'SELECT u.id,u.username,u.full_name,u.role,u.tenant_id,u.is_active,u.created_at,t.name AS tenant_name
                FROM users u
                LEFT JOIN tenants t ON t.id=u.tenant_id';
        $params = [];
        if ($search !== '') {
            $sql .= ' WHERE u.username LIKE ? OR u.full_name LIKE ?';
            $like = $this->sanitizeLike($search);
            $params[] = $like;
            $params[] = $like;
        }
        $sql .= ' ORDER BY u.id DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        jsonResponse(['users' => $stmt->fetchAll()]);
    }
    private function adminUserSave(): void {
        $this->requireRole(['admin']);
        $this->requirePost();
        $b = $this->jsonBody();
        $id = (int)($b['id'] ?? 0);
        $username = trim($b['username'] ?? '');
        $fullName = trim($b['full_name'] ?? '');
        $role = trim($b['role'] ?? 'kasir');
        $password = (string)($b['password'] ?? '');
        $tenantId = isset($b['tenant_id']) ? (int)$b['tenant_id'] : null;
        $isActive = (int)($b['is_active'] ?? 1) ? 1 : 0;
        if ($username === '' || $fullName === '' || !in_array($role, ['admin','kasir','tenant'], true)) {
            jsonResponse(['error' => 'Data user belum valid'], 400);
        }
        if ($role !== 'tenant') $tenantId = null;
        if ($password !== '' && strlen($password) < 6) {
            jsonResponse(['error' => 'Password minimal 6 karakter'], 400);
        }
        try {
            if ($id > 0) {
                if ($password !== '') {
                    db()->prepare('UPDATE users SET username=?,full_name=?,role=?,tenant_id=?,password=?,is_active=? WHERE id=?')
                        ->execute([$username,$fullName,$role,$tenantId,password_hash($password,PASSWORD_BCRYPT),$isActive,$id]);
                } else {
                    db()->prepare('UPDATE users SET username=?,full_name=?,role=?,tenant_id=?,is_active=? WHERE id=?')
                        ->execute([$username,$fullName,$role,$tenantId,$isActive,$id]);
                }
            } else {
                if ($password === '') jsonResponse(['error' => 'Password wajib diisi untuk user baru'], 400);
                db()->prepare('INSERT INTO users (username,password,full_name,role,tenant_id,is_active) VALUES (?,?,?,?,?,?)')
                    ->execute([$username,password_hash($password,PASSWORD_BCRYPT),$fullName,$role,$tenantId,$isActive]);
            }
        } catch (Throwable $e) {
            if ($this->isDuplicateKeyError($e)) {
                jsonResponse(['error' => 'Username sudah digunakan'], 400);
            }
            throw $e;
        }
        $this->adminUsers();
    }
    private function adminUserDelete(): void {
        $this->requireRole(['admin']);
        $this->requirePost();
        $id = (int)(($this->jsonBody())['id'] ?? 0);
        if ($id <= 0) jsonResponse(['error' => 'User tidak valid'], 400);
        if ($id === (int)$this->user['id']) jsonResponse(['error' => 'Akun aktif tidak bisa dihapus'], 400);
        db()->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
        jsonResponse(['success' => true]);
    }
    private function adminReportSales(): void {
        $this->requireRole(['admin']);
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT DATE(o.created_at) AS sale_date, COALESCE(SUM(o.total),0) AS total_sales, COUNT(*) AS total_orders
                FROM orders o
                WHERE o.status="selesai" AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY DATE(o.created_at)
                ORDER BY sale_date ASC';
        $s = db()->prepare($sql);
        $s->execute([$dateFrom,$dateTo]);
        jsonResponse(['rows' => $s->fetchAll()]);
    }
    private function adminReportSalesCsv(): void {
        $this->requireRole(['admin']);
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT DATE(o.created_at) AS sale_date, COALESCE(SUM(o.total),0) AS total_sales, COUNT(*) AS total_orders
                FROM orders o
                WHERE o.status="selesai" AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY DATE(o.created_at)
                ORDER BY sale_date ASC';
        $s = db()->prepare($sql);
        $s->execute([$dateFrom, $dateTo]);
        $rows = [];
        foreach ($s->fetchAll() as $r) {
            $rows[] = [$r['sale_date'], $r['total_orders'], $r['total_sales']];
        }
        $this->outputCsv('admin_sales_report.csv', ['Tanggal', 'Total Order', 'Total Penjualan'], $rows);
    }
    private function adminReportShare(): void {
        $this->requireRole(['admin']);
        $sharePercent = (float)($_GET['share_percent'] ?? 20);
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT t.id,t.name,
                    COALESCE(SUM(oi.subtotal),0) AS gross_sales
                FROM tenants t
                LEFT JOIN order_items oi ON oi.tenant_id=t.id
                LEFT JOIN orders o ON o.id=oi.order_id
                    AND o.status="selesai"
                    AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY t.id,t.name
                ORDER BY t.id ASC';
        $s = db()->prepare($sql);
        $s->execute([$dateFrom,$dateTo]);
        $rows = $s->fetchAll();
        foreach ($rows as &$row) {
            $gross = (float)$row['gross_sales'];
            $platform = $gross * ($sharePercent / 100);
            $tenantNet = $gross - $platform;
            $row['platform_fee'] = $platform;
            $row['tenant_net'] = $tenantNet;
            $row['share_percent'] = $sharePercent;
        }
        jsonResponse(['rows' => $rows]);
    }
    private function adminReportShareCsv(): void {
        $this->requireRole(['admin']);
        $sharePercent = (float)($_GET['share_percent'] ?? 20);
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT t.name, COALESCE(SUM(oi.subtotal),0) AS gross_sales
                FROM tenants t
                LEFT JOIN order_items oi ON oi.tenant_id=t.id
                LEFT JOIN orders o ON o.id=oi.order_id
                  AND o.status="selesai"
                  AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY t.id,t.name
                ORDER BY t.id ASC';
        $s = db()->prepare($sql);
        $s->execute([$dateFrom, $dateTo]);
        $rows = [];
        foreach ($s->fetchAll() as $r) {
            $gross = (float)$r['gross_sales'];
            $platform = $gross * ($sharePercent / 100);
            $rows[] = [$r['name'], $gross, $platform, $gross - $platform];
        }
        $this->outputCsv('admin_sharing_report.csv', ['Tenant', 'Omzet', 'Fee Platform', 'Pendapatan Tenant'], $rows);
    }

    // ── Tenant ─────────────────────────────────────────────
    private function tenantDashboard(): void {
        $this->requireRole(['tenant']);
        $tenantId = $this->tenantScopeId();
        $today = date('Y-m-d');
        $sales = db()->prepare('SELECT COALESCE(SUM(oi.subtotal),0)
                                FROM order_items oi
                                JOIN orders o ON o.id=oi.order_id
                                WHERE oi.tenant_id=? AND o.status="selesai" AND DATE(o.created_at)=?');
        $sales->execute([$tenantId,$today]);
        $orders = db()->prepare('SELECT COUNT(DISTINCT oi.order_id)
                                 FROM order_items oi
                                 JOIN orders o ON o.id=oi.order_id
                                 WHERE oi.tenant_id=? AND DATE(o.created_at)=?');
        $orders->execute([$tenantId,$today]);
        $products = db()->prepare('SELECT COUNT(*) FROM products WHERE tenant_id=? AND is_active=1');
        $products->execute([$tenantId]);
        jsonResponse([
            'today_income' => (float)$sales->fetchColumn(),
            'today_orders' => (int)$orders->fetchColumn(),
            'active_products' => (int)$products->fetchColumn(),
        ]);
    }
    private function tenantProducts(): void {
        $this->requireRole(['tenant']);
        $tenantId = $this->tenantScopeId();
        $search = trim($_GET['search'] ?? '');
        $sql = 'SELECT * FROM products WHERE tenant_id=?';
        $params = [$tenantId];
        if ($search !== '') {
            $sql .= ' AND name LIKE ?';
            $params[] = $this->sanitizeLike($search);
        }
        $sql .= ' ORDER BY id DESC';
        $s = db()->prepare($sql);
        $s->execute($params);
        jsonResponse(['products' => $s->fetchAll()]);
    }
    private function tenantProductSave(): void {
        $this->requireRole(['tenant']);
        $this->requirePost();
        $tenantId = $this->tenantScopeId();
        $b = $this->jsonBody();
        $id = (int)($b['id'] ?? 0);
        $name = trim($b['name'] ?? '');
        $price = (float)($b['price'] ?? 0);
        $stock = (int)($b['stock'] ?? 0);
        $stockMin = (int)($b['stock_min'] ?? 5);
        if ($name === '' || $price <= 0 || $stock < 0 || $stockMin < 0) jsonResponse(['error' => 'Data produk belum valid'], 400);
        try {
            if ($id > 0) {
                db()->prepare('UPDATE products SET name=?,price=?,stock=?,stock_min=?,is_available=?,is_active=? WHERE id=? AND tenant_id=?')
                    ->execute([$name,$price,$stock,$stockMin,(int)($b['is_available'] ?? 1),(int)($b['is_active'] ?? 1),$id,$tenantId]);
            } else {
                db()->prepare('INSERT INTO products (tenant_id,name,price,stock,stock_min,is_available,is_active) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$tenantId,$name,$price,$stock,$stockMin,(int)($b['is_available'] ?? 1),(int)($b['is_active'] ?? 1)]);
            }
        } catch (Throwable $e) {
            if ($this->isDuplicateKeyError($e)) {
                jsonResponse(['error' => 'Produk dengan nama ini sudah ada'], 400);
            }
            throw $e;
        }
        $this->tenantProducts();
    }
    private function tenantProductDelete(): void {
        $this->requireRole(['tenant']);
        $this->requirePost();
        $tenantId = $this->tenantScopeId();
        $id = (int)(($this->jsonBody())['id'] ?? 0);
        if ($id <= 0) jsonResponse(['error' => 'Produk tidak valid'], 400);
        db()->prepare('UPDATE products SET is_active=0,is_available=0 WHERE id=? AND tenant_id=?')->execute([$id, $tenantId]);
        jsonResponse(['success' => true]);
    }
    private function tenantOrders(): void {
        $this->requireRole(['tenant']);
        $tenantId = $this->tenantScopeId();
        $today = $_GET['date'] ?? date('Y-m-d');
        $status = trim($_GET['status'] ?? '');
        $sql = 'SELECT o.id,o.order_number,o.table_number,o.status,o.created_at,o.completed_at,
                       SUM(oi.subtotal) AS tenant_total
                FROM orders o
                JOIN order_items oi ON oi.order_id=o.id
                WHERE oi.tenant_id=? AND DATE(o.created_at)=?';
        $params = [$tenantId, $today];
        if ($status !== '') {
            $sql .= ' AND o.status=?';
            $params[] = $status;
        }
        $sql .= '
                GROUP BY o.id,o.order_number,o.table_number,o.status,o.created_at,o.completed_at
                ORDER BY o.id DESC';
        $s = db()->prepare($sql);
        $s->execute($params);
        jsonResponse(['orders' => $s->fetchAll()]);
    }
    private function tenantReport(): void {
        $this->requireRole(['tenant']);
        $tenantId = $this->tenantScopeId();
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT DATE(o.created_at) AS sale_date, COALESCE(SUM(oi.subtotal),0) AS revenue
                FROM orders o
                JOIN order_items oi ON oi.order_id=o.id
                WHERE oi.tenant_id=? AND o.status="selesai" AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY DATE(o.created_at)
                ORDER BY sale_date ASC';
        $s = db()->prepare($sql);
        $s->execute([$tenantId,$dateFrom,$dateTo]);
        jsonResponse(['rows' => $s->fetchAll()]);
    }
    private function tenantReportCsv(): void {
        $this->requireRole(['tenant']);
        $tenantId = $this->tenantScopeId();
        $dateFrom = $_GET['from'] ?? date('Y-m-01');
        $dateTo = $_GET['to'] ?? date('Y-m-d');
        $sql = 'SELECT DATE(o.created_at) AS sale_date, COALESCE(SUM(oi.subtotal),0) AS revenue
                FROM orders o
                JOIN order_items oi ON oi.order_id=o.id
                WHERE oi.tenant_id=? AND o.status="selesai" AND DATE(o.created_at) BETWEEN ? AND ?
                GROUP BY DATE(o.created_at)
                ORDER BY sale_date ASC';
        $s = db()->prepare($sql);
        $s->execute([$tenantId, $dateFrom, $dateTo]);
        $rows = [];
        foreach ($s->fetchAll() as $r) {
            $rows[] = [$r['sale_date'], $r['revenue']];
        }
        $this->outputCsv('tenant_income_report.csv', ['Tanggal', 'Pendapatan'], $rows);
    }
}
