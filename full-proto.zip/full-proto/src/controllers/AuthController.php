<?php
// ============================================================
// src/controllers/AuthController.php
// Login & Logout
// ============================================================

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../middleware/auth.php';

class AuthController {

    public function login(): void {
        requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (!$username || !$password) {
                $this->showLogin('Username dan password wajib diisi');
                return;
            }

            $stmt = db()->prepare(
                'SELECT u.*, t.name AS tenant_name
                 FROM users u
                 LEFT JOIN tenants t ON t.id = u.tenant_id
                 WHERE u.username = ? AND u.is_active = 1
                 LIMIT 1'
            );
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, $user['password'])) {
                $this->showLogin('Username atau password salah');
                return;
            }

            loginUser($user);
            $base = defined('BASE_PATH') ? BASE_PATH : '';
            header('Location: ' . $base . '/');
            exit;
        }

        $this->showLogin();
    }

    public function logout(): void {
        logoutUser();
        $base = defined('BASE_PATH') ? BASE_PATH : '';
        header('Location: ' . $base . '/login');
        exit;
    }

    private function showLogin(string $error = ''): void {
        include __DIR__ . '/../../views/pages/login.php';
    }
}
