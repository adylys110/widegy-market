<?php
// ============================================================
// src/middleware/auth.php
// Session & autentikasi
// ============================================================

require_once __DIR__ . '/../config/app.php';

function startSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function requireAuth(): array {
    startSession();
    if (empty($_SESSION['user'])) {
        if (isApiRequest()) {
            jsonResponse(['error' => 'Unauthorized'], 401);
        }
        $base = defined('BASE_PATH') ? BASE_PATH : '';
        header('Location: ' . $base . '/login');
        exit;
    }
    return $_SESSION['user'];
}

function requireGuest(): void {
    startSession();
    if (!empty($_SESSION['user'])) {
        $base = defined('BASE_PATH') ? BASE_PATH : '';
        header('Location: ' . $base . '/');
        exit;
    }
}

function currentUser(): ?array {
    startSession();
    return $_SESSION['user'] ?? null;
}

function loginUser(array $user): void {
    startSession();
    $_SESSION['user'] = [
        'id'        => $user['id'],
        'username'  => $user['username'],
        'full_name' => $user['full_name'],
        'role'      => $user['role'],
        'tenant_id' => $user['tenant_id'] ?? null,
        'tenant_name' => $user['tenant_name'] ?? null,
    ];
}

function logoutUser(): void {
    startSession();
    $_SESSION = [];
    session_destroy();
}

function isApiRequest(): bool {
    return (
        isset($_SERVER['HTTP_ACCEPT']) &&
        str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')
    ) || (
        isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
    );
}
