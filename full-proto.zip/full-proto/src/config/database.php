<?php
// ============================================================
// src/config/database.php
// Konfigurasi koneksi database MySQL
// Membaca dari environment variable (Docker) atau fallback XAMPP
// ============================================================

$serverName = $_SERVER['SERVER_NAME'] ?? 'localhost';
$isCli = PHP_SAPI === 'cli';
$isLocal = $isCli || in_array($serverName, ['localhost', '127.0.0.1'], true);

if ($isLocal) {
    define('DB_HOST',    'localhost');
    define('DB_PORT',    '3306');
    define('DB_NAME',    'warung_kuphi');
    define('DB_USER',    'root');
    define('DB_PASS',    '');
    define('DB_CHARSET', 'utf8mb4');
} else {
    define('DB_HOST',    'sql305.epizy.com');
    define('DB_PORT',    '3306');
    define('DB_NAME',    'epiz_12345678_warung');
    define('DB_USER',    'epiz_12345678');
    define('DB_PASS',    'password_kamu');
    define('DB_CHARSET', 'utf8mb4');
}
// ── PDO Singleton ────────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}
