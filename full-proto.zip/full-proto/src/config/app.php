<?php
// ============================================================
// src/config/app.php
// Konstanta aplikasi global
// ============================================================

define('APP_NAME',    'Warung Kuphi');
define('APP_VERSION', '2.0.0');
define('APP_URL',     '');   // kosong = relative

// Session
define('SESSION_NAME',     'wk_session');
define('SESSION_LIFETIME', 86400); // 24 jam

// Timezone
date_default_timezone_set('Asia/Makassar');

// ── Helper: format rupiah ────────────────────────────────────
function formatRupiah(float $amount, bool $withSymbol = true): string {
    $formatted = 'Rp ' . number_format($amount, 0, ',', '.');
    return $withSymbol ? $formatted : number_format($amount, 0, ',', '.');
}

// ── Helper: generate order number ───────────────────────────
function generateOrderNumber(): string {
    return 'WK-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
}

// ── Helper: sanitize output ──────────────────────────────────
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// ── Helper: JSON response ────────────────────────────────────
function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ── Helper: redirect ────────────────────────────────────────
function redirect(string $path): void {
    header('Location: ' . APP_URL . $path);
    exit;
}

// ── Helper: timeAgo ─────────────────────────────────────────
function timeAgo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)     return $diff . ' detik lalu';
    if ($diff < 3600)   return floor($diff / 60) . ' menit lalu';
    if ($diff < 86400)  return floor($diff / 3600) . ' jam lalu';
    return floor($diff / 86400) . ' hari lalu';
}

// ── Helper: formatDateTimeId ─────────────────────────────────
function formatDateTimeId(string $datetime): string {
    $bulan = ['', 'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'];
    $ts = strtotime($datetime);
    return date('d', $ts) . ' ' . $bulan[(int)date('m', $ts)] . ' ' . date('Y, H:i', $ts);
}
