<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Warung Kuphi — POS System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
<?php $base = defined('ASSET_BASE') ? ASSET_BASE : ''; ?>
<link rel="stylesheet" href="<?= $base ?>/assets/css/global.css">
<link rel="stylesheet" href="<?= $base ?>/assets/css/app-extra.css">
<style>
  /* Loading screen */
  #loading-screen {
    position:fixed; inset:0; z-index:9999;
    display:flex; flex-direction:column;
    align-items:center; justify-content:center; gap:18px;
    background:linear-gradient(135deg,#064e3b 0%,#047857 50%,#059669 100%);
  }
  #loading-screen .ls-icon { font-size:52px; animation:ls-pop .5s cubic-bezier(.34,1.56,.64,1); }
  #loading-screen .ls-name {
    font-family:'DM Serif Display',serif; font-size:24px;
    color:white; letter-spacing:.01em;
    animation:ls-pop .5s .1s cubic-bezier(.34,1.56,.64,1) both;
  }
  #loading-screen .ls-sub {
    font-size:12px; color:rgba(255,255,255,.6);
    letter-spacing:.1em; text-transform:uppercase; font-weight:500;
    animation:ls-pop .5s .15s ease both;
  }
  #loading-screen .ls-spinner {
    width:36px; height:36px;
    border:3px solid rgba(255,255,255,.2); border-top-color:white;
    border-radius:50%; animation:spin .8s linear infinite;
  }
  @keyframes ls-pop { from{opacity:0;transform:scale(.8) translateY(8px)} to{opacity:1;transform:none} }
  @keyframes spin { to{transform:rotate(360deg)} }
</style>
</head>
<body>

<div id="app-root" style="height:100vh;overflow:hidden"></div>

<!-- Loading screen (on top) -->
<div id="loading-screen">
  <div class="ls-icon">☕</div>
  <div class="ls-name">Warung Kuphi</div>
  <div class="ls-sub">Point of Sale System</div>
  <div class="ls-spinner"></div>
</div>

<!-- Toast container -->
<div id="toast-container" style="
  position:fixed; top:18px; right:18px; z-index:10000;
  display:flex; flex-direction:column; gap:8px; pointer-events:none;
"></div>

<!-- Pass auth data to JS -->
<script>
window.WK_USER = <?= json_encode([
  'id'        => $user['id'],
  'username'  => $user['username'],
  'full_name' => $user['full_name'],
  'role'      => $user['role'],
  'tenant_id' => $user['tenant_id'] ?? null,
  'tenant_name' => $user['tenant_name'] ?? null,
], JSON_UNESCAPED_UNICODE) ?>;
window.WK_BASE = <?= json_encode($base) ?>;
</script>

<?php
$role = $user['role'] ?? 'kasir';
$scriptMap = [
    'kasir'  => '/assets/js/kasir.js',
    'admin'  => '/assets/js/admin.js',
    'tenant' => '/assets/js/tenant.js',
];
$scriptFile = $scriptMap[$role] ?? '/assets/js/kasir.js';
?>
<script src="<?= $base . $scriptFile ?>"></script>
</body>
</html>
