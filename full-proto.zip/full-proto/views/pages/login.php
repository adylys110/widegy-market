<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Login — Warung Kuphi</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;font-family:'Plus Jakarta Sans',sans-serif}
body{overflow:hidden}
.login-root{
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  padding:24px;position:relative;overflow:auto;
  background:radial-gradient(circle at 15% 20%, rgba(16,185,129,.14), transparent 32%),
             radial-gradient(circle at 85% 78%, rgba(16,185,129,.14), transparent 34%),
             linear-gradient(140deg,#0f172a 0%,#064e3b 46%,#065f46 100%);
}
.login-card{
  width:100%;max-width:430px;border-radius:24px;overflow:hidden;
  background:rgba(255,255,255,.97);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.4);
  box-shadow:0 30px 80px rgba(0,0,0,.35);
  animation:fadeEnter .42s cubic-bezier(.22,1,.36,1);
}
@keyframes fadeEnter{
  from{opacity:0;transform:translateY(20px) scale(.98)}
  to{opacity:1;transform:translateY(0) scale(1)}
}
.login-top{padding:28px 30px 14px}
.brand-row{display:flex;align-items:center;gap:12px}
.brand-icon{
  width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg,#10b981,#047857);color:#fff;font-size:22px;font-weight:700;
}
.brand-name{font-family:'DM Serif Display',serif;font-size:22px;color:#0f172a;line-height:1.1}
.brand-sub{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#64748b;font-weight:600}
.login-form-wrap{padding:18px 30px 32px}
.login-title{font-size:24px;font-weight:800;color:#0f172a;margin-bottom:4px}
.login-desc{font-size:13px;color:#64748b;margin-bottom:22px}
.form-group{margin-bottom:14px}
.form-label{display:block;font-size:12px;font-weight:700;color:#334155;margin-bottom:6px}
.login-input-wrap{position:relative;display:flex;align-items:center}
.login-input-icon{position:absolute;left:12px;font-size:14px;opacity:.7}
.form-input{
  width:100%;height:46px;border:1.5px solid #e2e8f0;border-radius:12px;
  padding:10px 12px 10px 38px;font-size:14px;font-family:inherit;color:#0f172a;background:#f8fafc;
  outline:none;transition:border-color .18s,box-shadow .18s,background .18s;
}
.form-input:focus{border-color:#059669;box-shadow:0 0 0 3px rgba(5,150,105,.13);background:#fff}
.login-eye-btn{
  position:absolute;right:10px;border:none;background:transparent;font-size:14px;cursor:pointer;
  width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;
}
.login-eye-btn:hover{background:#f1f5f9}
.login-error{
  background:#fef2f2;border:1px solid #fecaca;color:#b91c1c;border-radius:10px;
  padding:10px 12px;margin-bottom:14px;font-size:13px;font-weight:500;
}
.btn-login{
  width:100%;height:48px;border:none;border-radius:12px;margin-top:8px;
  background:linear-gradient(135deg,#059669,#047857);color:#fff;
  font-size:15px;font-weight:700;font-family:inherit;cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:8px;
  transition:transform .15s,box-shadow .15s,opacity .15s;
}
.btn-login:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 10px 28px rgba(5,150,105,.33)}
.btn-login:disabled{opacity:.65;cursor:not-allowed}
.spinner{
  width:15px;height:15px;border:2px solid rgba(255,255,255,.3);
  border-top-color:#fff;border-radius:50%;animation:spin .8s linear infinite
}
@keyframes spin{to{transform:rotate(360deg)}}
@media (min-width:768px) and (max-width:1180px){
  .login-root{padding:28px}
  .login-card{max-width:500px}
  .login-title{font-size:26px}
  .form-input{height:50px;font-size:15px}
  .btn-login{height:52px;font-size:16px}
}
@media (max-width:520px){
  .login-root{padding:14px}
  .login-top{padding:22px 18px 10px}
  .login-form-wrap{padding:16px 18px 24px}
}
</style>
</head>
<body>
<div class="login-root">
  <div class="login-card">
    <div class="login-top">
      <div class="brand-row">
        <div class="brand-icon">☕</div>
        <div>
          <div class="brand-name">Warung Kuphi</div>
          <div class="brand-sub">Point of Sale System</div>
        </div>
      </div>
    </div>

    <div class="login-form-wrap">
      <h2 class="login-title">Masuk</h2>
      <p class="login-desc">Akses panel sesuai peran Anda.</p>
      <form method="POST" action="<?= defined('BASE_PATH') ? BASE_PATH : '' ?>/login" id="loginForm">
        <?php if (!empty($error)): ?>
          <div class="login-error"><?= e($error) ?></div>
        <?php endif; ?>
        <div class="form-group">
          <label class="form-label">Username</label>
          <div class="login-input-wrap">
            <span class="login-input-icon">👤</span>
            <input class="form-input" type="text" name="username" placeholder="Masukkan username" value="<?= e($_POST['username'] ?? '') ?>" autocomplete="username" autofocus required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="login-input-wrap">
            <span class="login-input-icon">🔒</span>
            <input class="form-input" type="password" name="password" id="passInput" placeholder="Masukkan password" autocomplete="current-password" required>
            <button type="button" class="login-eye-btn" id="eyeBtn" aria-label="toggle password">👁️</button>
          </div>
        </div>
        <button type="submit" class="btn-login" id="submitBtn">
          <span id="btnText">Masuk</span>
          <div class="spinner" id="btnSpinner" style="display:none"></div>
        </button>
      </form>
    </div>
  </div>
</div>
<script>
document.getElementById('eyeBtn').addEventListener('click', function () {
  const inp = document.getElementById('passInput');
  const showing = inp.type === 'text';
  inp.type = showing ? 'password' : 'text';
  this.textContent = showing ? '👁️' : '🙈';
});
document.getElementById('loginForm').addEventListener('submit', function () {
  const btn = document.getElementById('submitBtn');
  btn.disabled = true;
  document.getElementById('btnText').textContent = 'Memproses...';
  document.getElementById('btnSpinner').style.display = 'block';
});
</script>
</body>
</html>
