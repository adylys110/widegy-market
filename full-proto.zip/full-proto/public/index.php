<?php
// ============================================================
// public/index.php — Front Controller
// Docker  : DocumentRoot = /public → BASE_PATH = ''
// XAMPP   : htdocs/warung-kuphi-php/ → BASE_PATH = /warung-kuphi-php
// ============================================================

define('ROOT', dirname(__DIR__));

require_once ROOT . '/src/config/app.php';
require_once ROOT . '/src/config/database.php';
require_once ROOT . '/src/middleware/auth.php';

startSession();

// ── Deteksi BASE_PATH ────────────────────────────────────────
// SCRIPT_NAME di Docker  : /index.php        → dir = /   → base = ''
// SCRIPT_NAME di XAMPP   : /warung-kuphi-php/public/index.php → base = /warung-kuphi-php
$scriptDir = dirname($_SERVER['SCRIPT_NAME']); // /public atau /warung-kuphi-php/public
$basePath  = dirname($scriptDir);              // / atau /warung-kuphi-php
if ($basePath === '/' || $basePath === '\\' || $basePath === '.') {
    $basePath = '';
}
define('BASE_PATH', $basePath);

// ── Parse URI (strip base path) ──────────────────────────────
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = $basePath !== ''
    ? substr($requestUri, strlen($basePath))
    : $requestUri;
$uri = rtrim($uri ?: '/', '/') ?: '/';

// ── Static assets (fallback kalau Apache tidak serve langsung) ─
if (preg_match('#^/(assets|favicon)#', $uri)) {
    $filePath = ROOT . $uri;
    if (file_exists($filePath) && is_file($filePath)) {
        $ext  = pathinfo($filePath, PATHINFO_EXTENSION);
        $mime = match($ext) {
            'css'        => 'text/css',
            'js'         => 'application/javascript',
            'png'        => 'image/png',
            'jpg','jpeg' => 'image/jpeg',
            'svg'        => 'image/svg+xml',
            'ico'        => 'image/x-icon',
            default      => 'application/octet-stream',
        };
        header('Content-Type: ' . $mime);
        readfile($filePath);
        exit;
    }
}

// ── API routes ───────────────────────────────────────────────
if (str_starts_with($uri, '/api/')) {
    require_once ROOT . '/src/controllers/ApiController.php';
    $action = ltrim(str_replace('/api/', '', $uri), '/');
    (new ApiController())->handle($action);
    exit;
}

// ── Auth routes ──────────────────────────────────────────────
if ($uri === '/login') {
    require_once ROOT . '/src/controllers/AuthController.php';
    (new AuthController())->login();
    exit;
}

if ($uri === '/logout') {
    require_once ROOT . '/src/controllers/AuthController.php';
    (new AuthController())->logout();
    exit;
}

// ── Main app (harus login) ───────────────────────────────────
$user = requireAuth();

define('ASSET_BASE', BASE_PATH);

include ROOT . '/views/layouts/app.php';
