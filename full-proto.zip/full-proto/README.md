# ☕ Warung Kuphi — POS System (PHP + MySQL)

Tidak perlu Node.js, Supabase, atau build step.  
Langsung jalan di **Docker** atau **XAMPP**.

---

## 🐳 Cara Pakai — Docker (Direkomendasikan)

### Langkah 1 — Stop container lama (kalau ada)
```bash
docker-compose down -v
```

### Langkah 2 — Build & jalankan
```bash
docker-compose up -d --build
```
> Tunggu ~60 detik pertama kali (download image + import SQL)

### Langkah 3 — Setup password akun
```bash
docker exec warung_kuphi_app php setup.php
```

### Langkah 4 — Buka browser
| URL | Keterangan |
|-----|------------|
| `http://localhost:8080` | Aplikasi POS |
| `http://localhost:8081` | phpMyAdmin (root / secret) |

### Login
| Role  | Username | Password   |
|-------|----------|------------|
| Kasir | `kasir`  | `kasir123` |
| Admin | `admin`  | `admin123` |
| Tenant| `tenant.a` | `tenant123` |

---

## ⚠️ Troubleshooting Docker

**403 Forbidden?**
```bash
# Rebuild dari awal (bukan reuse cache lama)
docker-compose down -v
docker-compose up -d --build
docker exec warung_kuphi_app php setup.php
```

**Database belum siap?**
```bash
# Cek log
docker logs warung_kuphi_db
docker logs warung_kuphi_app
```

**Mau reset total?**
```bash
docker-compose down -v          # hapus container + volume DB
docker-compose up -d --build    # rebuild fresh
docker exec warung_kuphi_app php setup.php
```

---

## 🖥️ Cara Pakai — XAMPP

1. Copy folder ke: `C:\xampp\htdocs\warung-kuphi-php\`
2. Buka phpMyAdmin → buat database `warung_kuphi` → Import `database.sql`
3. Jalankan: `php setup.php`
4. Buka: `http://localhost/warung-kuphi-php/`

---

## ✅ Quick QA (Phase 6-10)

1. Login `admin` lalu cek menu Dashboard, Tenants, Products, Orders, Reports, Sharing, Users.
2. Tambah tenant baru, tambah produk tenant, tambah user tenant.
3. Login `tenant.a`, cek dashboard, tambah menu, lihat orders/report tenant.
4. Login `kasir`, buat transaksi sampai selesai dengan item tenant.
5. Kembali ke admin/tenant dan pastikan laporan sinkron.
6. Coba export CSV:
   - Admin: laporan sales dan sharing
   - Tenant: laporan pendapatan
7. Uji error handling:
   - Submit form kosong / invalid
   - Filter data per tanggal/status/search

---

## 📁 Struktur Folder

```
warung-kuphi-php/
├── Dockerfile               ← Build image PHP+Apache
├── docker-compose.yml       ← Orkestrasi Docker
├── docker/
│   └── apache.conf          ← Konfigurasi Apache (DocumentRoot → /public)
├── public/
│   ├── index.php            ← Front controller
│   └── .htaccess
├── src/
│   ├── config/
│   │   ├── app.php          ← Helper & konstanta
│   │   └── database.php     ← PDO (auto-detect env var)
│   ├── controllers/
│   │   ├── ApiController.php
│   │   └── AuthController.php
│   └── middleware/
│       └── auth.php
├── views/
│   ├── layouts/app.php
│   └── pages/login.php
├── assets/
│   ├── css/global.css
│   ├── css/app-extra.css
│   └── js/app.js
├── database.sql             ← Schema + seed data
└── setup.php                ← Fix password hash
```
