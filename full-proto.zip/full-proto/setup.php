#!/usr/bin/env php
<?php
// ============================================================
// setup.php — Jalankan sekali setelah import database.sql
// Usage: php setup.php
// ============================================================

require_once __DIR__ . '/src/config/database.php';
require_once __DIR__ . '/src/config/app.php';

echo "╔══════════════════════════════════════╗\n";
echo "║    WARUNG KUPHI — Setup Script       ║\n";
echo "╚══════════════════════════════════════╝\n\n";

// Fix password hashes
$accounts = [
    ['kasir', 'kasir123', 'Budi Santoso',  'kasir', null],
    ['admin', 'admin123', 'Admin Warung',  'admin', null],
    ['tenant.a', 'tenant123', 'PIC Tenant A', 'tenant', 1],
    ['tenant.b', 'tenant123', 'PIC Tenant B', 'tenant', 2],
    ['tenant.c', 'tenant123', 'PIC Tenant C', 'tenant', 3],
];

$db = db();

foreach ($accounts as [$username, $password, $fullName, $role, $tenantId]) {
    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $db->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $exists = $stmt->fetch();

    if ($exists) {
        $db->prepare('UPDATE users SET password=?, full_name=?, role=?, tenant_id=? WHERE username=?')
           ->execute([$hash, $fullName, $role, $tenantId, $username]);
        echo "✅ Updated: $username (password: $password)\n";
    } else {
        $db->prepare('INSERT INTO users (username, password, full_name, role, tenant_id) VALUES (?,?,?,?,?)')
           ->execute([$username, $hash, $fullName, $role, $tenantId]);
        echo "✅ Created: $username (password: $password)\n";
    }
}

echo "\n✅ Setup selesai!\n";
echo "   Akun kasir : kasir / kasir123\n";
echo "   Akun admin : admin / admin123\n\n";
echo "   Akun tenant: tenant.a / tenant123 (tenant b/c sama)\n\n";
echo "📌 Jalankan di browser: http://localhost/warung-kuphi-php/\n";
